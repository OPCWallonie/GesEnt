<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>Gestion des collaborateurs</title>
<meta name="keywords" content="" lang="fr">
<meta name="description" content="">

<meta http-equiv="Content-Language" content="fr">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<!--[if IE]><script language="javascript" type="text/javascript" src="http://www.wuro.fr/static/js/excanvas.js"></script><![endif]-->	

<link rel="stylesheet" type="text/css" href="../css/ajouter_-_supprimer_-_modifier_un_collaborateur.css" media="all">
<script language="JavaScript" type="text/javascript" SRC="../scripts/div.js"></script>
</head>
<body>

<?php
include ("./menu.php");
$action = $_GET['action'];
                    
if ($action == "extra_add") {
	$txt_bouton = 'Ajouter';
	echo "<script>javascript:visibilite('extra_edit');</script>";

						}
elseif ($action =="extra_modify") {
	$txt_bouton = 'Modifier';
	echo "<script>javascript:visibilite('extra_edit');</script>";
	
}
else {
	$action = "liste";
	$txt_bouton = 'Ajouter';
	
	}
?>

<div id="contenant">
		

<div class="box">
	<h2>Frais extraordinaires</h2>
		
			
		
	<!--###############################################################
	############################# MENU ################################
	###############################################################-->
 
	<ul id="menu">
	        <li>
		<a <?php if ($action=="liste") { ?> class="active"<?php } ?> href="?action=liste" rel="user_list"><img src="../images/clipboard_64.png" alt="Liste des utilisateurs"> <span>Liste</span></a>
        </li>
    					
		<li>
					<a <?php if ($action=="extra_add" or $action=="extra_modify") { ?> class="active"<?php } ?> href="../rh-outils/ajouter_des_frais_extraordinaires.html?action=extra_add" rel="user_add"><img src="../images/clipboard_add.png" alt="Ajouter un utilisateur"> <span><?php echo $txt_bouton; ?></span></a>
				</li>
    
        </ul>
	
	<!--###############################################################
	############### AFFICHAGE DE MESSAGES DIVERS... ###################
	###############################################################-->
	
		<div id="messages" class="">
					</div>

	<!--###############################################################
	####################### LISTING DES USERS #########################
	###############################################################-->
    
    
		
	<div id="extra_list" class="content">
	
	
			
				
        <table cellspacing="0">
            <tbody><tr>
                <th colspan="2" class="aleft" width="400">Dénomination</th>
               
                <th class="aleft" width="100">Montant HT</th>
                <th class="aleft" width="100">Montant TVAC</th>
                <th colspan="2">&nbsp;</th>
                
            </tr>
            
            <tr id="lig1782" class="alternate">
                                <td width="64"><img src="../images/euro.png" alt="cscpl" height="64" width="64"></td>
                                <td class="vtop"><strong></strong></td>
								<td class="vtop"></td>
                                <td class="vtop"></td>
                                <td class="vtop" width="32"></td>
                                <td class="vtop" width="32"><a href="../rh-outils/ajouter_des_frais_extraordinaires.html?action=extra_modify" title="Modifier"><img src="../images/pencil.png" alt="Modifier"></a></td>
                                </tr>
                                        
        </tbody></table>
        

        
	</div>
    
    
    
    
	
	

	
</div></div>

<?php
include('./footer.php');
?>

</body>
</html>
