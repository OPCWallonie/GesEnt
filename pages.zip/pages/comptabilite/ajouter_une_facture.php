

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
// CONSTANTES
echo $_POST['cocontractants'];





// Récupération des autres valeurs du formulaire
$frais_de_port = $_POST['frais_de_port'];
$nomClient = $_POST['nomClient'];
$adresse = $_POST['adresse'];
$code_postal = $_POST['code_postal'];
$ville = $_POST['ville'];
$pays = $_POST['pays'];
$tva_intra = $_POST['tva_intra'];
$code_client = $_POST['code_client'];
$mail_client = $_POST['mail_client'];
$mode_reglement = $_POST['mode_reglement'];
$etat_payement = $_POST['etat_payement'];
$fact_paye = $_POST['fact_paye'];
$fact_date = $_POST['fact_date'];
$notes = $_POST['notes'];
$acompte = $_POST['acompte'];
$ristourne_globale = $_POST['ristourne_globale'];





// Si ma variable de session contenant les données de la facture existe, je la recharge et dé-sérialise dans un tableau fact_data
if (isset($_SESSION['fact_data'])){
	$fact_data = $_SESSION['fact_data'];
	$taille = count($fact_data);
	}
else {
	$taille=0;
}

$action = $_GET['action'];



if ($action == 'update_infos_ligne')
{
$taille = $_GET['id']; // Entourloupe pour utiliser la mise en place du tableau ci-dessous ;)
}
if ($action == 'ajouter_ligne' OR $action == 'update_infos_ligne')
{
// Nous allons regarder si la valeur du post précédent est égal au poste actuel... Si c'est le cas, on stocke les données dans la variable de session

if ($fact_data[$taille-1]['designation'] != $_POST['designation'] && $fact_data[$taille-1]['prix'] != $_POST['prix']) // On s'évite des doublons
	{
		$fact_data[$taille] = array( 	designation => $_POST['designation'],
										detail => $_POST['detail'],
										prix => $_POST['prix'],
										remise => $_POST['remise'],
										unite_remise => $_POST['unite_remise'],
										qte => $_POST['qte'],
										tva => $_POST['tva'],
										montant => $_POST['montant']
								 
						);
$_SESSION['fact_data'] = $fact_data;
unset($designation);
unset($detail);
unset($prix);
unset($remise);
unset($unite_remise);
unset($qte);
unset($tva);
unset($montant);

	}





// On place les constantes de la facture dans une variable de session... De cette manière elles sont sauvegardées et accessibles.
$pour_variable_session = array(	origine => 'facture',
								frais_de_port => $_POST['frais_de_port'],
								nomClient => $_POST['nomClient'],
								adresse => $_POST['adresse'],
								code_postal => $_POST['code_postal'],
								ville => $_POST['ville'],
								pays => $_POST['pays'],
								tva_intra => $_POST['tva_intra'],
								code_client => $_POST['code_client'],
								mail_client => $_POST['mail_client'],
								mode_reglement => $_POST['mode_reglement'],
								etat_payement => $_POST['etat_payement'],
								fact_paye => $_POST['fact_paye'],
								fact_date => $_POST['fact_date'],
								ristourne_globale => $_POST['ristourne_globale'],
								notes => $_POST['notes'],
								
								cocontractants => $_POST['cocontractants'],
								acompte => $_POST['acompte']);

$_SESSION['infos_generales'] = $pour_variable_session;
unset($frais_de_port);

		// Sous-if de redirection... En effet maintenant que les données sont enregistrées dans les variables de sessions, on peut dès lors vérifier que l'utilisateur n'a pas cliqué sur le bouton "enregistrer et imprimer"... Si tel est le cas, on le re-dirige vers notre page imprime_doc.php
		
if ((isset($_POST['imprime_doc'])) && ($_POST['imprime_doc'] == "Enregistrer et Imprimer"))
			{
		
echo '<meta http-equiv="Refresh" content="0;url=../comptabilite/imprime_doc.html">';
				exit;
			}




}
elseif ($action == 'supp_ligne')
	{	
		// 
		$id=$_GET['id']; // Quel ID a supprimer est référencé dans l'URL
		unset($fact_data[$id]); // On supprime le contenu de la ligne
		array_splice($fact_data, $id, 0); // On supprime de la mémoire la ligne
		$_SESSION['fact_data'] = $fact_data; // On enregistre les modifs dans la variable de session
		
		
	}

if ($action == 'modif_ligne')
	{
		// On va d'abord lire l'ID de la ligne à modifier
		$id = $_GET['id'];
		$id_ligne = $id; // Certes je pense que ça ne sert à rien MAIS à vérifier plus tard... utilisé dans le div id="form_ajout_ligne" et surtout à la définition de notre formulaire2 afin de pouvoir appliquer les modifs plus tard
		
		
		// Après il nous faut lire les données à ré-injecter dans le div "form_ajout_ligne" et les attribuer à des variable que nous allons définir
$designation = $fact_data[$id]['designation'];
$detail = $fact_data[$id]['detail'];
$prix = $fact_data[$id]['prix'];
$remise = $fact_data[$id]['remise'];
$unite_remise = $fact_data[$id]['unite_remise'];
$qte = $fact_data[$id]['qte'];
$tva = $fact_data[$id]['tva'];
$montant = $fact_data[$id]['montant'];
		
	}


	
	
	
// Je charge les autres données qui sont stockées dans ma variable de session...
$infos_generales = $_SESSION['infos_generales'];	




?>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Ajouter une facture</title>
<link rel="stylesheet" type="text/css" href="../css/facture_ajout.css" media="all" />



<script language="JavaScript" type="text/JavaScript">

function afficher()
{
  var a = document.getElementById("fact_payee" );
  var m = document.getElementById("fact_a_payer" );
    a.style.display = "block";
    m.style.display = "none";
}
 
function masquer()  
{  
  var a = document.getElementById("fact_payee" );  
  var m = document.getElementById("fact_a_payer" );  
 a.style.display = "none";  
 m.style.display = "block";  
}

function initial()  
{  
  var a = document.getElementById("fact_payee" );  
  var m = document.getElementById("fact_a_payer" );  
 a.style.display = "block";  
 m.style.display = "none";  
}



</script>


</head>


<?php 
// J'active par défaut si on affiche fact_paye ou fact_a_payer
if ($infos_generales['etat_payement'] == "1")
	{ echo '<body onLoad="javascript:afficher();">'; }
elseif ($infos_generales['etat_payement'] == "2")
	{ echo '<body onLoad="javascript:masquer();">'; }
else { echo '<body onLoad="javascript:initial();">'; }

include ("./menu.php");
?>


<div id="contenant">
		<span class="hide" id="type_doc">factures</span>




<div class="box">
	<h2>Gestion des factures</h2>
		
	
	<!--###############################################################
	############################# MENU ################################
	###############################################################-->
   
    		<ul id="menu">
        	        		<li>
		        						<a class="nonactif" href="../comptabilite/facture.html" rel="factures_list">
						<img src="../images/order-history64.png" alt="Liste des factures"> 
						<span>Liste des factures</span>
					</a>
        		</li>
			
							<li>
					<a href="../comptabilite/facture_ajout.html" rel="facture_add" class="active">
						<img src="../images/ordering64.png" alt="Créer une nouvelle facture">
						<span>Ajouter une facture</span>
					</a>
				</li>
						
        	
			    	</ul>
    



	
	
		
<div style="display: block;" id="facture_add" class=" content">

<?php
// Je décide ce qui se passe si on clique sur modifier ou sur ajouter... vu que action=modif_ligne si on veut modifier, je modifie l'entête du formulaire afin qu'il envoit vers la fonction update de données et non pas insert... 

if ($action == "modif_ligne")
{
	echo '<form id="formulaire2" method="post" enctype="multipart/form-data" action="?action=update_infos_ligne&id='.$id_ligne.'" >';
}
else
{
	echo '<form id="formulaire2" method="post" enctype="multipart/form-data" action="?action=ajouter_ligne" >';
}

// Date du jour


?>



			<input name="documentId" id="documentId" value="" type="hidden">
			<input name="action" value="ajout" type="hidden">
			<input name="type_document" id="type_document" value="factures" type="hidden">
            
 <?php
 // Ici on ira chercher les informations factures afin d'avoir un numéro de facture... Ce numéro sera inscrit dans la variable de session à facture... Je rempli déjà le modèle

if (!isset($_SESSION['numero_facture']))
	{
		$_SESSION['numero_facture'] = "2013-000001"; // A changer plus tard	
	}

echo '           
<h2 id="numero_document">Facture n° '.$_SESSION['numero_facture'].'</h2>';
?>            
            
			<p class="toggle open">
				<a href="javascript:visibilite('client_infos');" class="options_devis">Client</a>
			</p>
			

<div id="client_infos">

				<fieldset id="choix_client">
					
					<p class="gris01">
						
						
						<span class="toolTip" title="Renseignez dans ce champ le nom ou la société de votre client <br />
Ce nom apparaîtra dans lentête de la facture">&nbsp;</span>

						<label for="nomClient">Société ou nom :</label>
						
						<input autocomplete="off" name="nomClient" class="textfield" id="nomClient" value="<?php if (isset($infos_generales)) echo $infos_generales['nomClient']; ?>" placeholder="Nom du client" type="text"> 					
						
					</p>
						
					<p>
						<span class="toolTip" title="L'adresse de votre client apparaîtra dans l'entête de la facture">&nbsp;</span>
						<label for="adresse">Adresse : </label>
						<textarea name="adresse" id="adresse" cols="40" rows="2" placeholder="Adresse du client"><?php if (isset($infos_generales)) echo $infos_generales['adresse']; ?></textarea>
					</p>
                    
					<p class="gris01">
						<span class="toolTip" title="Le code postal apparaîtra dans l'entête de la facture">&nbsp;</span>
						<label for="code_postal">Code postal : </label>

						<input autocomplete="off" name="code_postal" class="textfield" id="codePostal" placeholder="Code Postal" type="text" value="<?php if (isset($infos_generales)) echo $infos_generales['code_postal']; ?>" /> 
						
					</p>
	
    				<p>	
						<span class="toolTip" title="La ville apparaîtra dans l'entête de la facture">&nbsp;</span>
						<label for="ville">Ville :</label>
						<input name="ville" class="textfield" id="ville" placeholder="Ville" type="text" value="<?php if (isset($infos_generales)) echo $infos_generales['ville']; ?>" />
					</p>
                    
					<p class="gris01">
						<span class="toolTip" title="Le pays apparaîtra dans l'entête de la facture">&nbsp;</span>
						<label for="pays">Pays :</label>
						<input name="pays" class="textfield" id="pays" placeholder="Pays" type="text" value="<?php if (isset($infos_generales)) echo $infos_generales['pays']; ?>" />					
					</p>
                    
					<p>
						<span class="toolTip" title="Si l'entreprise à facturer possède un numéro de tva intracommunautaire spécifiez-le dans ce champ<br />
Celui-ci apparaitra dans l'entête de la facture. Le numéro de TVA est composé du préfixe du pays suivi d'au maximum 12 chiffres ou caractères alphanumériques">&nbsp;</span>
						<label for="tva_intra">N° TVA intra :</label>
						<input name="tva_intra" class="textfield" id="tva_intra" placeholder="TVA" type="text" value="<?php if (isset($infos_generales)) echo $infos_generales['tva_intra']; ?>" />
					</p>
                    
					<p class="gris01">
						<span class="toolTip" title="Spécifiez le code client qui vous permettra de retrouver la facture lors d'une recherche par code client">&nbsp;</span>
						<label for="code_client">Code compta/client :</label>
						<input name="code_client" id="code_client" class="textfield" placeholder="Code Client" type="text" value="<?php if (isset($infos_generales)) echo $infos_generales['code_client']; ?>" />
					</p>
						
						
						
					<p>
						<span class="toolTip" title="Renseignez l'adresse e-mail du client">&nbsp;</span>
						<label for="mail_client">E-mail :</label>
						<input name="mail_client" id="mail_client" class="textfield" placeholder="e-mail" type="text" value="<?php if (isset($infos_generales)) echo $infos_generales['mail_client']; ?>" />
					</p>
										
					
				</fieldset>
			</div>
            
            
            
<p class="toggle open">
				<a href="javascript:visibilite('facturation_infos');" class="options_devis">Facturation</a>
			</p>			
			
            

			
<div id="facturation_infos">
		
				<fieldset>
					
					<div id="ajouter_ligne">		
                        
                        
                        <p class="gris01">
                        <span class="toolTip" title="L'ajout de nouveaux moyens de paiement est effectué par les administrateur du site à la chambre de la construction de Liège">&nbsp;</span>
							
<label for="mode_reglement">Mode de réglement : </label>

<?php
// On récupère les données nécessaires à la suite du traitement des moyens de payements
		mysql_query('set names utf8'); // Instruction magique qui normalise les accents et permet d'avoir les mêmes caractères côté base et côté site... Ce qui ne gâche rien ;)
		$requete = 'SELECT id, nom, defaut, utilise FROM ' . $tab_modepayement ;
		$mysql_result = mysql_query($requete, $db);
?>   

 
							<select name="mode_reglement" id="mode_reglement">
								
<?php
							while($data = mysql_fetch_assoc($mysql_result))
							{
// Si la variable infos_generales existe... Autrement dit si on a déjà donné des infos, on sait qu'on va tomber sur la valeur enregistrée en parcourant le tableau => est-ce que infos_generales est = à nom, alors data default devient 1

if (isset($infos_generales)) {
	$data['defaut'] = '0';
	
	if ($infos_generales['mode_reglement'] == $data['nom']) 
	{
		$data['defaut'] = '1';
	}
}

echo '<option value="'.$data['nom'].'" ';
	
if ($data['defaut'] == '1' ) { echo 'selected="selected" '; }						
							
echo '>'.$data['nom'].'</option>';
							
							}
?>
							
							
							</select>
						</p>
						
						<p>
							<span class="toolTip" title="Précisez si la facture est ou non payée">&nbsp;</span>
							<label for="etat_paiement">Etat du paiement : </label>

<?php

if ($infos_generales['etat_payement'] == '1')
	{ $aplacer = 'checked="checked"'; } 
?>  
                         
                            
							<input name="etat_payement" id="etat_payement" class="facture_etat_paiement radio" value="1" <?php echo $aplacer ; ?> type="radio" OnClick="javascript:afficher();"> Payé |  <input name="etat_payement" id="etat_payement" class="facture_etat_paiement radio" value="2" type="radio" <?php if (!isset($aplacer) && $aplacer != 'checked="checked"') { echo 'checked="checked"';}?>   OnClick="javascript:masquer();"> Paiement en attente
						</p>
							
						<div id="fact_payee">
							<p class="gris01">
								<span class="toolTip" title="Si la facture est payée, indiquez la date de paiement">&nbsp;</span>
								<label for="fact_paye">Date du paiement : </label>
								<input id="fact_paye" name="fact_paye" class="textfield" maxlength="10" size="10" placeholder="JJ/MM/AAAA" type="text" value="<?php if (isset($infos_generales)) echo $infos_generales['fact_paye']; ?>" />
							</p>
						</div>
                       
                        <div id="fact_a_payer">
                        <p class="gris01">
							<span class="toolTip" title="Une fois la date limite de paiement dépassée la facture passera de l'état &quot;en attente&quot; à l'état &quot;payé&quot;">&nbsp;</span>
							<label for="date_validite">Date limite de paiement : </label>
							<input class="textfield" name="fact_date" id="fact_date" maxlength="10" size="10" placeholder="JJ/MM/AAAA" type="text" value="<?php if (isset($infos_generales)) echo $infos_generales['fact_date']; ?>" />
						</p>
                        </div>
													
						<!--
						<p class="gris01">
							<label for="accompte_montant">Accompte : </label>
							<input type="text" name="accompte_montant" class="textfield" id="accompte_montant" style="width:100px;" value="0" />
							<select name="accompte_type">
								<option value="pourcent" >&nbsp;%</option>
								<option value="valeur" >&nbsp;€</option>
							</select>
						</p>
						-->
						<input name="accompte_montant" class="textfield" id="accompte_montant" style="width: 100px;" value="0" type="hidden"><input name="accompte_type" value="pourcent" type="hidden">
						
						<p>
							<span class="toolTip" title="Les frais de port HT associés à la facture">&nbsp;</span>
							<label for="frais_de_port">Frais de port HT : </label>
							<input name="frais_de_port" class="textfield" id="frais_de_port" style="width: 80px;" value="<?php if (isset($infos_generales)) echo $infos_generales['frais_de_port']; ?>" placeholder="00.00" type="text">&nbsp;€
						</p>
                        
					  				
						
						<p class="gris01">
							<span class="toolTip" title="Montant de la remise globale HT en pourcentage. Cette option est paramétrable dans l'espace de gestion des clients">&nbsp;</span>
							<label for="ristourne_globale">Remise globale HT : </label>
							<input type="text" name="ristourne_globale" id="ristourne_globale" value="<?php if (isset($infos_generales)){ echo $infos_generales['ristourne_globale'].'%';}else echo "O%" ?>" size="2" placeholder="0" />
                           
						</p>
                        
                        <p>
							<span class="toolTip" title="Acompte payé à déduire du montant total de la facture">&nbsp;</span>
							<label for="acompte">Acompte : </label>
							<input name="acompte" class="textfield" id="acompte" style="width: 80px;" value="<?php if (isset($infos_generales)) echo $infos_generales['acompte']; ?>" placeholder="00.00" type="text">&nbsp;€
                            
						</p>	
                        
                        
 <p class="gris01">
            	<span class="toolTip" title="Dans le cas d'une TVA entre cocontractants, il n'est plus obligatoire depuis le 1er Janvier 2013 de référer à l'article de loi sur le report de perception. La nouvelle mention légale &quot;autoliquidation&quot; apparaîtra sur votre facture.">&nbsp;</span>
                <label for="cocontractants">TVA cocontractants : </label>
<input type="checkbox" name="cocontractants" id="cocontractants" class="textfield" value="oui" <?php if ($infos_generales['cocontractants'] == 'oui'){echo 'checked="checked"';}?> />
            </p>                       
            
                        			
					</div>
				</fieldset>
			</div>

	

<div id="form_ajout_ligne" class="gris01 gras padding5">
				
				<input name="id_ligne" id="id_ligne" value="<?php echo $id_ligne; ?>" type="hidden">
				<input name="type_taxe" id="type_taxe" value="ht" type="hidden">
				<input name="ht_ttc_remise" id="ht_ttc_remise" value="ht" type="hidden">
				
				<div class="ligne_designation fleft">
					Désignation : <input value="<?php echo $designation; ?>" autocomplete="off" name="designation" id="designation" class="textfield" style="width: 85%;" type="text" placeholder="Produit/Service facturé" />
					
				
						<div class="suggestionsBox" id="suggestions_designation" style="left: 0px;">
							<img src="../images/uparrow.png" alt="upArrow">
							<div class="suggestionList" id="autoSuggestionsList_designation">
								&nbsp;
							</div>
							<div class="hide">devis/autoCompleteProduit</div>
						</div>	
						<input name="idesignation" id="id_autoCompleteDesignation" type="hidden">
					
					
				</div>
				
				
				<div class="ligne_prix_ht fleft acenter">
					Prix unitaire HT<br>
					<input class="textfield aright" name="prix" id="prix" value="<?php echo $prix; ?>" type="text" placeholder="00.00" />&nbsp;€
				</div>

				
				<div class="ligne_remise_ht fleft acenter">
					Remise HT<br>
					<input class="textfield aright" value="<?php echo $remise; ?>" id="remise" name="remise" type="text" placeholder="00.00" />
					                    
                    <select style="" name="unite_remise" id="unite_remise">
<?php
if ($unite_remise == "€") 
{
	echo '<option value="€" selected="selected">€</option>
						<option style="background-color: rgb(227, 227, 227);" value="%">%</option>';
}
elseif ($unite_remise == "%")
{
	echo '<option value="€">€</option>
						<option style="background-color: rgb(227, 227, 227);" value="%" selected="selected">%</option>';
}
else 
{
	echo '<option value="€">€</option>
						<option style="background-color: rgb(227, 227, 227);" value="%">%</option>';
}
	
?>                    
                    
                    
						
					</select> 
					<input name="ht_ou_ttc" id="ht_ou_ttc" value="ht" type="hidden" />
				</div>				
		
				
				<div class="ligne_qte fleft acenter">
					Qté<br />
					<input class="textfield fleft aright" value="<?php if ($action== 'modif_ligne') {echo $qte;} else {echo '1';} ?>" id="qte" name="qte" type="text" />
                    <a href="#" class="qte_plus"><img src="../images/plus.png" alt="+" style="margin: 2px;"></a>
					<a href="#" class="qte_moins"><img src="../images/moins.png" alt="-" style="margin: 2px;"></a>
				</div>


			
				<div class="ligne_tva fleft acenter">
					TVA<br>
					<select name="tva" id="tva" />

<?php
// On récupère les données nécessaires à la suite du traitement des taux de TVA
		$requete = 'SELECT id, tva FROM ' . $tab_tauxtva . ' ORDER BY tva ASC' ;
		$mysql_result = mysql_query($requete, $db);
$champs_tva = ' ';		
$i=0;		
		while($data = mysql_fetch_assoc($mysql_result))
							{
								
	$table_TVA[$i] = $data['tva'];
	$i++;	
								
if($data['tva'] == $tva)
	{
		$selected = "selected='selected'";
		
	}	
elseif ($champs_tva == $data['tva']) 
	{
	$selected = "selected='selected'";
	}

else{
	$selected = '&nbsp;';
	}




								// $tva[$i]=$data['tva'];
								$champs_tva = $champs_tva."<option value='".$data['tva']."'".$selected.">".$data['tva']." %</option>";
								
								// $i++;
							}
$taille_table_TVA = count($table_TVA); // Quelle taille fait donc notre table ?
echo $champs_tva;	
?> 
                    
</select>
				</div>
				


				<div class="ligne_montant fleft acenter">
					Montant TTC<br>
					<input class="textfield aright" name="montant" id="montant" value="<?php echo $montant; ?>" type="text">&nbsp;€
				</div>
				
								
				
				
				<div class="ligne_detail margin-top clear">
				Détail : <br>
					<textarea name="detail" id="detail" rows="5" cols="50"><?php echo $detail; ?></textarea>
				</div>
		
        
<?php
// Ici on va définir si il faut afficher "insérer ligne" ou "modifier ligne"     
if ($action == 'modif_ligne') 
	{
?>
<p class="acenter">
					<a class="button" onclick='javascript:document.getElementById("formulaire2").submit()' id="modifier_ligne_doc"><span><img alt="Modifier ligne" src="../images/pencil.png"> Modifier cette ligne</span></a>
				</p>
<?php                
	}
else
	{
?>		
		<p class="acenter">
					<a class="button" onclick='javascript:document.getElementById("formulaire2").submit()' id="ajouter_ligne_doc"><span><img alt="Ajouter ligne" src="../images/disk.png"> Insérer cette ligne</span></a>
				</p>
<?php                
	}
?>   
        
        		
				
			</div>
			
<?php
if (isset($fact_data)){
?>
			
            
			<span id="tableauLignes">
		<table id="tab_document" class="margin-top" cellspacing="0">
			<tbody><tr>
				<th width="20">#</th>
				<th>Designation</th>
				<th width="70">Prix u. HT</th>
                <th width="50">Qté</th>
				<th width="100">Remise HT</th>
                <th width="100">Ristourne HT</th>	
				<th width="70">Montant HT</th>
			</tr>
            
<?php
// Nous allons charger les paramètres du tableau contenant les données de factures ( $fact_data ). Notre tableau à la forme $fact_data[$ligne]["valeur"]

$tab_fact_max = count($fact_data);
for ($i=0; $i<$tab_fact_max; $i++){
	
// Premièrement je calcule sur l'élément en cours son Prix HT* quantité moins la remise

	// On en profite pour calculer le total prix unitaire * quantité
	$elem_HT = $fact_data[$i]['prix']*$fact_data[$i]['qte'];

	// Pour cela, je veux savoir si il s'agit d'une remise en € ou en % 
	// Si jamais l'unite de remise est l'euro, on fait une simple 		addition sinon on converti d'abord en euros avant d'additionner en dessous...

// Je crée une valeur _tmp afin de la ré-utiliser

if ($fact_data[$i]['unite_remise']=="€")
		{
			$remise_HT_tmp = $fact_data[$i]['remise'];	
		}
	else {
			$remise_HT_tmp = $elem_HT*($fact_data[$i]['remise']/100);
		}
	
// On en profite pour calculer le total prix unitaire * quantité
	$elem_HT = $fact_data[$i]['prix']*$fact_data[$i]['qte'];		
		
		
	// Ensuite je peux effectuer le calcul... Pour ce faire j'enlève encore les X pourcents de Ristourne client ( celle qui se trouve dans les paramètres du client... La Ristourne globale donc !	
	
$prix_HT = $elem_HT-$remise_HT_tmp;  // j'enlève déjà la 1ere remise sur le produit que j'ai calculé ci-dessus...

	// Je calcule maintenant le montant la ristourne globle en €

	$ristourne_globale_calc = $elem_HT*($ristourne_globale/100);

	// Et je soustrait ma ristourne globale du prix...
	
	$prix_HT = $prix_HT - $ristourne_globale_calc;


// Je calcule maintenant la TVA sur ce prix HT - remise - ristourne

$tva_de_prix = $prix_HT*($fact_data[$i]['tva']/100);

// Maintenant je dois classifier les TVAs...
// Donc : Est-ce que j'ai une base à 6, 12 ou 21 ? Je vais comparer dans mon tableau des valeurs...

// Je me crée une boucle qui va regarder les divers taux proposés. Ensuite comparer les taux avec celui en cours $fact_data[$i]['tva']. Si c'est le même, on ajoute le montant à la variable adéquate.

for($j=0; $j<$taille_table_TVA; $j++)
{

$tmp = $fact_data[$i]['tva']; // par simplicité de lecture pour la suite...

if ($table_TVA[$j] == $tmp)
	{
		$total_base_TVA[$tmp] = $total_base_TVA[$tmp] + $prix_HT;
		$total_TVA[$tmp] = $total_TVA[$tmp] + $tva_de_prix;
	}
}

// TOUTES LES INFOS POUR LE TABLEAU TVA SONT DONC LA...

// Maintenant on s'attaque au tableau récapitulatif...

// Je calcule donc le montant hors TVA 	
	
	$montant_HT = $montant_HT + $prix_HT;

	
	
	echo '<tr id="'.$i.'"><td class="vtop">'.$i.'</td>
	 <td class="aleft">
		<div>'.$fact_data[$i]['designation'].'</div>'.$fact_data[$i]['detail'].'
<p style="visibility: hidden;" class="ligne_modifs"><a href="?action=modif_ligne&id='.$i.'" class="modif_ligne simple_button margin-right small">

<img src="../images/pencil.png" alt="Modifier"> Modifier la ligne</a> <a href="?action=supp_ligne&id='.$i.'" class="simple_button suppr_ligne small"><img src="../images/delete_001.png" alt="Supprimer"> Supprimer la ligne</a></p>
							</td>
<td class="vtop cell_prix_ht aright">'.$fact_data[$i]['prix'].' &euro;</td>

<td class="vtop cell_qte aright">'.$fact_data[$i]['qte'].'</td>							
														
<td class="vtop cell_remise aright">'.$remise_HT_tmp.' €';
// si l'unité de la remise est le % alors on affiche :
	if ($fact_data[$i]['unite_remise'] == "%")
		{
			echo '<p style="font-size:9px">'.$fact_data[$i]['remise'].' '.$fact_data[$i]['unite_remise'].'</p></td>';
		}
		
// Si il y a une ristourne globale on l'affiche
echo '<td class="vtop cell_remise aright">';

if (isset($ristourne_globale) && $ristourne_globale != '0' && $ristourne_globale != '' )
	{
		echo $ristourne_globale_calc.' €<p style="font-size:9px">'.$ristourne_globale.'% </p>';
	}
		

echo '</td>
							
							
							<td class="vtop cell_total aright">'.$prix_HT.' &euro;
							<p style="font-size:12px">TVA : '.$fact_data[$i]['tva'].' %</p>					
							</td>
						</tr>';
}

// Et je continue ici le calcul sur le tableau récapitulatif
	

// Maintenant place à la remise globale sur le montant HT - remise HT en pourcents

	


// Calcul en direct du montant HT
$total_HT = $montant_HT; // Il s'agit d'une réminiscence d'ancien codes... Je garde ces 2 variables dans le doute... A nettoyer plus tard ! 


// TOTAL TTC !!!!!!!!!!!!!!!!!!!!!!
	// On calcule toute la TVA accumulée plus haut dans le tableau

for ($i=0;$i<$taille_table_TVA;$i++)
	{
$tmp = $table_TVA[$i];		
		
$TVA_a_payer = $TVA_a_payer + $total_TVA[$tmp]; 
	}

// Maintenant on peut ajouter au total HT la TVA	
	
$total_TTC= $total_HT+$TVA_a_payer;





?>
						
						</tbody></table></span>
<?php
//fermeture du "if isset fact_data"
}
?>
		
					
		<input name="liste_tva" id="liste_tva" value="" type="hidden">
		<input name="montant_tva" id="montant_tva" value="" type="hidden">
		<input name="total_tva" id="total_tva" value="" type="hidden">
		<input name="total_port" id="total_port" value="0.00" type="hidden">
		<input name="montantHT" id="montantHT" value="" type="hidden">
		<input name="montantTTC" id="montantTTC" value="" type="hidden">
		<input name="montant_remise" id="montant_remise" value="1" type="hidden">			
			
			
		<hr>
		<div class="margin-top gras">
			Notes :<br>
			<textarea name="notes" cols="60" rows="6" class="large"><?php if (isset($infos_generales)) echo $infos_generales['notes']; ?></textarea>
		</div>
        
<br />        
           
<div id="blocTVA"> <!-- Je crée ici un tableau de TVA -->
	<table class="tableau_tva margin-bottom margin-top" cellspacing="0">
    	<tr>
        	<td>
            Taux TVA
            </td>
            <td>
            TVA calculée
            </td>
        <tr>

<?php


for($i=0; $i<$taille_table_TVA; $i++){
echo '<tr>';

if ($table_TVA[$i] != 0)
	{
$tmp = $table_TVA[$i];
$total_TVA[$tmp] = round($total_TVA[$tmp], 2);
	echo '<td>'.$total_base_TVA[$tmp].' €</td>';	
	echo '<td>'.$tmp.' %</td>';	
	// On va maintenant ajouter le total TVA inhérent au taux en cours
	echo '<td>'.$total_TVA[$tmp].' €</td>';
	

	}
echo '</tr>';
}

?>        
        
    </table>
</div>
			
			
		<div id="blocTotaux">				
        <table class="tableau_totaux margin-bottom margin-top" cellspacing="0">
					<tbody>
					
								
					<tr><td>Total HT : <br></td><td><span id="totalHT">
<?php


echo $total_HT;?>&nbsp;€</span><br></td></tr>

<tr>
                    	<td>TVA : </td>
                    	<td id="totalTVA"> <?php echo $TVA_a_payer; ?>&nbsp;€</span>


</td></tr>


							
					<tr><td>Total TTC :</td><td id="totalTTC"><?php 
				
					echo $total_TTC; ?>&nbsp;€</td></tr>
                    
          
          
               
                    
                    
                    
<tr>
<td>Frais de port :</td>
<td><span id="totalFdp"><?php echo $infos_generales['frais_de_port'];?> €</span>
						</td>
					</tr>                    
                    
                    

<?php // calcul Net à payer
$total_net = $total_TTC + $infos_generales['frais_de_port'];
?>					
	
						
                    
					<tr><th>Net à&nbsp; payer TTC :</th><th id="netTTC"><?php echo $total_net; ?>&nbsp;€</th></tr>
				</tbody></table>
			</div>
			
		<hr>
			
		<p id="validation_ajout_devis" class="gris01 acenter">
			<!--
			<input type="submit" name="etat" value="Enregistrer en brouillon" class="margin-right" />
			<input type="submit" name="etat" value="Aperçu et enregistrer" />
			-->
			<input name="etat" value="Enregistrer & Imprimer" id="submit_form" type="hidden">
			<a href="#" class="button margin-right" rel="Enregistrer"><span><img src="../images/disk.png" alt="enregistrer"> Enregistrer</span></a> 
							<input  type="submit" name="imprime_doc" id="imprime_doc" value="Enregistrer et Imprimer" />
                            
				
		</p>
	</form>	
			</div>	
		
	
	
	
	
</div>
</div>








</div>
<?php
include('./footer.php');
?>
</body>
</html>