<?php
$origine = $_GET['origine'];
$id = $_GET['id'];



switch ($origine){
	case 'dev':
	$connectBD = $tab_devis;
	$renvoi = "../comptabilite/devis.html";
	break;
	
	case 'bdc':
	$connectBD = $tab_bdc;
	$renvoi = "../comptabilite/bons_de_commandes.html";
	break;
	
	case 'facture':
	$connectBD = $tab_facture;
	$renvoi = "../comptabilite/facture.html";
	break;
		
	}




$link = mysqli_connect($db_host,$db_login,$db_pass,$db_base);

/* Vérification de la connexion MySQLi */
if (mysqli_connect_errno()) {
    printf("Échec de la connexion : %s\n", mysqli_connect_error());
    exit();
}
	
	
	/* change character set to utf8 */
if (!mysqli_set_charset($link, "utf8")) {
    printf("Il est impossible de charger le langage utf8: %s\n", mysqli_error($link));
} 

	// on crée la requete SQL en MySQLi Procédural
	$query = "SELECT * FROM ".$connectBD." WHERE id LIKE '" .$id. "' ";
	$result = mysqli_query($link, $query);
	

	$cnt = 0; // J'initialise un petit compteur

	// Et maintennt je vérifie qu'un devis dans la base n'est pas = à celui qu'on vient de transférer...
	while($data = mysqli_fetch_assoc($result))
	
	{	
		$id = $data['id'];
		$dev_tva_affil = $data['dev_tva_affil'];
		$devNum = $data['dev_num'];
		$bdcNum = $data['bdc_num'];
		$factNum = $data['fact_num'];
		$annexes_id = $data['annexes_id'];
		$dateDoc = $data['dateDoc'];
		$frais_de_port = $data['dev_frais_de_port'];
		$nomClient = $data['dev_nomClient'];
		$adresse = $data['dev_adresseClient'];
		$code_postal = $data['dev_codePostal'];
		$ville = $data['dev_ville'];
		$pays = $data['dev_pays'];
		$tva_intra = $data['tvaClient']; 
		$code_client = $data['dev_codeClient'];
		$mail_client = $data['dev_mailClient'];
		$mode_reglement = $data['dev_modeReglement'];
		$etat_payement = $data['dev_etatPayement'];
		$fact_paye = $data['dev_factPayee'];
		$fact_date = $data['dev_factDate'];
		$ristourne_globale = $data['dev_ristourneGlobale'];
		$notes = $data['dev_notes'];
		$date_validite = $data['dev_dateValidite'];
		$cocontractants = $data['dev_cocontract'];
		$delai_reglement = $data['dev_delaiReglement'];
		$acompte = $data['dev_aCompte'];
		$dev_serialize = $data['dev_serialize'];
		$tva = $data['tva'];
		$montant = $data['montant'];
		$etat = $data['etat'];
		$date_etat = $data['date_etat'];
		$actio = '';
												
	}



// Que faut-il afficher en haut du document ? On regarde d'où on vient et on affiche dès lors facture, bon de commande ou devis.
// Pour ce faire je prends le numéro de document, je l'explose et je regarde si il s'agit d'un DEV/BDC ou FAC...

switch ($origine) {
case facture:
	$titre = 'Facture N° '.$factNum.' du '.$dateDoc;
	$libelle = "facture";
	break;
case devis:
	$titre = 'Devis N° '.$devNum.' du '.$dateDoc;
	$libelle = "devis";
	break;
case bdc:
	$titre = 'Bon de commande N° '.$bdcNum.' du '.$dateDoc;
	$libelle = "bon de commande";
	break;
}
	



?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $titre; ?></title>
<link rel="stylesheet" type="text/css" href="../css/imprime_doc.css" media="all" />
<link rel="stylesheet" type="text/css" media="print" href="../css/print.css" />
<?php
// Rechargement de mes données de facture
unset($fact_data); // Je vide ma variable
$fact_data = unserialize($dev_serialize); // Je désérialise mes données de facturation
$infos_generales = $data;
$taille = count($fact_data);
?> 

</head>
<body>
		

	
	


<div id="apercu_devis" style="border: medium none; padding: 0px;">
			
			<div style="margin-top: 10px;">
				<div class="acenter gras" style="border-bottom: 1px solid black;">
                
<?php 
echo $titre; // On affiche le nom de la facture
?> 				
                 </div>
				
				<div style="width: 250px; padding: 10px; margin: 10px; float: left;">
								
					<?php echo '<p>Par : <strong>'.$_SESSION['ent_nom'].'</strong> '.$_SESSION['ent_stat'].'</p>					
                    <p><strong>'.$_SESSION['ent_adresse'].'<br />
					'.$_SESSION['ent_cp'].' '.$_SESSION['ent_localite'].'</strong></p>';

echo '<p>Tél : '.$_SESSION['ent_tel'].'<br />
		 Fax : '.$_SESSION['ent_fax'].'<br />
		 N° d\'entreprise : '.$_SESSION['ent_tva'].'</p>';
		
		
					
					?>																				
				</div>
           
                
			
				<div style="width: 325px; margin-top:3.3cm; margin-right:1cm; float: right;">
 
<?php
// Mes infos du client
				
echo '<p style="font-size:16px">Pour : <strong>'.$nomClient.'</strong></p>					
<p style="font-size:14px">'.$adresse.'</p>					
<p style="font-size:14px">'.$code_postal.' '.$ville.'</p>					
<p>'.$pays.'</p>										
					<p style="font-weight: bold;">N° de TVA : '.tva_intra.'</p>					
<p>Code client : '.$code_client.'</a></p>';
?>
				</div>
				
				<hr>
			</div>
<?php // Ci dessous je vérifie bien qu'on a une info et qu'on est dans devis afin d'afficher une date de validité :)
if (isset($_SESSION['infos_generales']) && $date_validite != '' && $libelle=="devis") {
	echo '<h3>Ce devis est valable jusqu\'au '.$date_validite.'</3>';	 
}
?>
			
			
			<div style="margin-top: 10px;">
				<table id="tab_document" cellspacing="0">
					<tbody><tr>
                    	<th class="acenter bleu" style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);" width="20">#</th>
						<th class="acenter bleu" style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);">Désignation</th>
						<th class="acenter bleu" style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);" width="25">Qté</th>
                        <th class="acenter bleu" style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);" width="50">Unité</th>
                        <th class="acenter bleu" style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);" width="50">Prix u.HT</th>
                        
						<th class="aright bleu" style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);" width="50">Remise HT</th>
						<th class="aright bleu" style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);" width="35">Ristourne HT</th>
						<th class="aright bleu" style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);" width="75">Montant HT</th>
					</tr>
<?php
// Nous allons charger les paramètres du tableau contenant les données de factures ( $fact_data ). Notre tableau à la forme $fact_data[$ligne]["valeur"]

$tab_fact_max = count($fact_data);

for ($i=0; $i<$tab_fact_max; $i++){
	
// Premièrement je calcule sur l'élément en cours son Prix HT* quantité moins la remise

	// On en profite pour calculer le total prix unitaire * quantité
	$elem_HT = $fact_data[$i]['prix']*$fact_data[$i]['qte'];

	// Pour cela, je veux savoir si il s'agit d'une remise en € ou en % 
	// Si jamais l'unite de remise est l'euro, on fait une simple 		addition sinon on converti d'abord en euros avant d'additionner en dessous...

// Je crée une valeur _tmp afin de la ré-utiliser

if ($fact_data[$i]['unite_remise']=="€")
		{
			$remise_HT_tmp = $fact_data[$i]['remise'];	
		}
	else {
			$remise_HT_tmp = $elem_HT*($fact_data[$i]['remise']/100);
		}		
		
	// Ensuite je peux effectuer le calcul... Pour ce faire j'enlève encore les X pourcents de Ristourne client ( celle qui se trouve dans les paramètres du client... La Ristourne globale donc !	
	
$prix_HT = $elem_HT-$remise_HT_tmp;  // j'enlève déjà la 1ere remise sur le produit que j'ai calculé ci-dessus...

	// Je calcule maintenant le montant la ristourne globle en €

	$ristourne_globale_calc = $elem_HT*($ristourne_globale/100);
	
	// Et je soustrait ma ristourne globale du prix...
	
	$prix_HT = $prix_HT - $ristourne_globale_calc;
	
	
	$montantGlobal = $montantGlobal + $prix_HT;
	$TVA_a_payer = $montantGlobal*($tva/100);
	$total_TTC = $montantGlobal*(1+($tva/100));
	


	
	echo '<tr id="'.$i.'"><td class="vtop">'.$i.'</td>
	 						<td class="aleft"><div>'.$fact_data[$i]['designation'].'</div>'.$fact_data[$i]['detail'].'</td>
							<td class="vtop cell_qte aright">'.$fact_data[$i]['qte'].'</td>
							<td class="vtop cell_qte aright">'.$fact_data[$i]['unite'].'</td>
							<td class="vtop cell_prix_ht aright">'.$fact_data[$i]['prix'].' &euro;</td>
							
							<td class="vtop cell_remise aright">'.$remise_HT_tmp.' €';
// si l'unité de la remise est le % alors on affiche :
	if ($fact_data[$i]['unite_remise'] == "%")
		{
			echo '<p style="font-size:9px">'.$fact_data[$i]['remise'].' '.$fact_data[$i]['unite_remise'].'</p></td>';
		}
		
// Si il y a une ristourne globale on l'affiche
echo '<td class="vtop cell_remise aright">';

if (isset($ristourne_globale) )
	{
		echo $ristourne_globale_calc.' €<p style="font-size:9px">'.$ristourne_globale.'% </p>';
	}
echo '</td>
							
							
							<td class="vtop cell_total aright">'.$prix_HT.' &euro;			
							</td>
						</tr>';
}

// Et je continue ici le calcul sur le tableau récapitulatif
	

// Maintenant place à la remise globale sur le montant HT - remise HT en pourcents

	


// Calcul en direct du montant HT
$total_HT = $montant_HT; // Il s'agit d'une réminiscence d'ancien codes... Je garde ces 2 variables dans le doute... A nettoyer plus tard ! 





?> 
			
				</tbody></table>

<div id="blocTVA">  <!-- Je crée ici un tableau de TVA --> 
<?php               
// On va vérifier que la case co-contractants n'était pas cochée sinon on affiche à la place du tableau TVA la mention légale
if ($tva == "0")
	{ 
		echo '<br /><br /><h3 class="cocontractants">Autoliquidation</h3>';
		$TVA_a_payer = '0'; // La TVA a payer devient 0€
	}
else // Donc si on est pas en cocontractants alors on calcule le total net + TVA et... C'est bon
	{
  ?>              

	<table class="tableau_tva margin-bottom margin-top" cellspacing="0"> 
    	<tr>
        <td style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);">Base TVA</td>
        	<td style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);">
            Taux TVA
            </td>
            <td style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);">
            TVA calculée
            </td>
        <tr>
<tr>

<?php

$total_TVA[$tmp] = round($total_TVA[$tmp], 2);
	echo '<td>'.$montantGlobal.' €</td>';
	echo '<td>'.$tva.' %</td>';	
	// On va maintenant ajouter le total TVA inhérent au taux en cours
	echo '<td>'.$montant.' €</td>';
	

	}
echo '</tr>';

?>
</table>
<?php
 // fin du if cocontractant
?>

</div> 
  
 
<?php
           
?>				
								
				<div id="blocTotaux">				
        <table class="tableau_totaux margin-bottom margin-top" cellspacing="0">
					<tbody>
					
								
					<tr><td>Total HT : <br></td><td><span id="totalHT">
<?php


echo $montantGlobal;?>&nbsp;€</span><br></td></tr>

<tr>
                    	<td>TVA : </td>
                    	<td id="totalTVA"> <?php 
						$TVA_a_payer = round($TVA_a_payer,2); // Arrondi
						echo $TVA_a_payer; ?>&nbsp;€</span>


</td></tr>


							
					<tr><td>Total TTC :</td><td id="totalTTC"><?php 
					$total_TTC = round($total_TTC,2);
					echo $total_TTC; ?>&nbsp;€</td></tr>
                    
          
          
               
                    
                    
                    
<tr>
<td>Frais de port :</td>
<td><span id="totalFdp"><?php echo $frais_de_port;?> €</span>
						</td>
					</tr>                    
                    
                    

<?php // calcul Net à payer
$total_net = $total_TTC + $frais_de_port;

// Ensuite je regarde si il y avait un acompte, si oui je modifie la tableau pour qu'il calcule un sous total puis ensuite un Reste à payer

if (isset($acompte) && $acompte != '0' && $acompte != '') {
	echo '
	<tr><th style="background-color: rgb(135, 206, 250); color: rgb(0, 0, 0);">Net TTC :</th><th id="netTTC" style="background-color: rgb(135, 206, 250); color: rgb(0, 0, 0);">'.$total_net.' €</th></tr>
	
	<tr>
		<td>Acompte</td>
		<td>- '.$acompte.' €</td>
	</tr>';
	
// Calcul du reste à payer...	

$total_net = $total_net-$acompte;
$valeur_a_afficher = "Restant à payer TTC :";
}
else
	{
		$valeur_a_afficher = "Net à payer TTC :";
	}
?>					
	
						
                    
					<tr><th style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);"><?php echo $valeur_a_afficher; ?></th><th id="netTTC" style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);"><?php echo $total_net; ?>&nbsp;€</th></tr>
				</tbody></table>
			</div>
				
						
			
			<hr>

			
			<div class="autres_infos" style="padding: 10px; margin-top: 10px;">
            <!-- l'argument de style "page-break-after" provoque un saut de page afin de pouvoir imprimer les conditions générales au verso ;) -->
				
<?php
// Doit on afficher une note ?
if ($notes != "")
	{
		$notes = nl2br($notes);
		echo '<p><strong>Note : </strong>'.$notes.'</p><br />';
	}

if ($fact_date != '')
{
	echo '<strong>limite de paiement : '.$fact_date.'</strong><br />';
}
elseif ($fact_paye != '')
{
	echo '<strong>Facture payée le : '.$fact_paye.'</strong><br />';
}
						
?>										
					<strong style="text-decoration:underline">Conditions de règlement :</strong> <?php echo $mode_reglement; ?><br />
<?php
if (isset($infos_generales) && $delai_reglement != '') {
	echo 'Facture à payer à j+'.$delai_reglement;	 
}					
?>
					
			</div>
            				
<div align="center" style="margin-top:50px">	
<a href="<?php echo $renvoi;?>" class="button margin-right" id="button" rel="enreg"><span><img src="../images/pencil.png" alt="enreg">Retour</span></a>
<a onclick="javascript:window.print();" class="button margin-right" id="button" rel="imprime"><span><img src="../images/printer.png" alt="imprime"> Imprimer</span></a>
</div>

<?php
if (file_exists('./images/condgen/'.$_SESSION['ent_affil'].'_condgen.jpg'))
	{
		echo '
		<div class="cond_gen" style="page-break-before:always">
		<img src="../images/condgen/'.$_SESSION['ent_affil'].'_condgen.jpg" style="height : '.$_SESSION['condGen']['hauteur'].'cm ; width : '.$_SESSION['condGen']['largeur'].'cm; margin-left:'.$_SESSION['condGen']['marGauche'].'cm; margin-top:'.$_SESSION['condGen']['marHaut'].'cm;" />
		</div>';
	}



	
?>
</div>
</div>
</body>
</html>























