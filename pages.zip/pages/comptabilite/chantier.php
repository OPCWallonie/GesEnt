<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Untitled Document</title>

<script type="text/javascript" src="../scripts/inherited/text.js"></script>

<style type="text/css" >
* { margin: 0px; padding: 0px; }
body { color: rgb(0, 0, 0); font: 0.8em/1.3em "Trebuchet MS",Verdana,"Lucida Grande",Tahoma,Helvetica,Sans-Serif; }
a, a:visited { color: rgb(0, 0, 0); outline: medium none; text-decoration: none; }
a:hover { text-decoration: underline; }
h1 { display: none; }
p { margin-bottom: 1.3em; }
div#logo { background: none repeat scroll 0% 0% rgb(255, 255, 255); border: 1px solid rgb(230, 230, 230); margin: 20px auto 1px; width: 498px; text-align: center; }
form#chantier { background: url('../images/home-top.png') no-repeat scroll 0px 100% rgb(218, 218, 218); margin: 0px auto; width: 476px; padding: 10px; border: 1px solid rgb(255, 255, 255); }
form#chantier label { font-size: 1.6em; float: left; width: 145px; margin-right: 5px; margin-bottom: 10px; color: rgb(60, 60, 60); text-shadow: 1px 1px 0px rgb(255, 255, 255); line-height: 40px; }
form#chantier input.textfield { width: 300px; font-size: 1.3em; color: rgb(60, 60, 60); background: none repeat scroll 0% 0% rgb(255, 255, 255); border: 1px solid rgb(191, 191, 191); padding: 7px; vertical-align: middle; font-weight: bold; }
form#chantier input.textfield:focus { border: 1px solid rgb(60, 60, 60); }
form#chantier input.submit { background: none repeat scroll 0% 0% rgb(60, 60, 60); color: rgb(255, 255, 255); width: 220px;  padding: 7px; border: 0px none; border-radius: 5px 5px 5px 5px; font-weight: bold; }
form#chantier input.submit:hover { cursor: pointer; background-color: rgb(51, 51, 51); }
form#chantier input.submit:focus { cursor: pointer; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); }
form#chantier label.remember { float: none; font-size: 0.8em; text-shadow: none; color: rgb(0, 0, 0); width: auto; line-height: 1; margin-bottom: 0px; }
div.message { margin-bottom: 10px; padding: 5px; }
div.message.info { background: none repeat scroll 0% 0% rgb(218, 235, 243); border: 1px solid rgb(168, 216, 235); }
div.message.info span { display: block; background: url('../images/exclamation.png') no-repeat scroll 0px 0px transparent; padding-left: 20px; }

#sb-nav-close { background-image: url('../images/cross.png'); }
</style>


</head>
<?php
$i = $_GET['numDoc'];

include('./menu.php');

if (isset($_POST['nomChantier'])) {
	// On peut enregistrer dans la base puis rediriger vers la bonne page :)
	$_SESSION['devis_data'][$i]['chantier'] = $_POST['nomChantier'];
	echo '<meta http-equiv="Refresh" content="0;url=ajouter_un_bon_de_commande.html?action=transit&origine=bdc&numDoc='.$i.'">';
		
}

?>

<body>


<div id="quel_browser" title="Chantier">
<p>&nbsp;</p>
<form action="#" method="post" id="chantier">
<p align="center">Veuillez lier ce nouveau bon de commande à un chantier ( qu'il soit nouveau ou déjà existant ) :</p>
<p align="center">
  <input type="text" id="nomChantier" name="nomChantier" />
</p>
<p align="center"><input type="submit" class="submit" value="Continuer..." /></p>



    
<?php			
		// Je me connecte
		$mysqli = new mysqli($db_host,$db_login,$db_pass,$db_base);
		// check connection 
		if (mysqli_connect_errno()) {
			printf("Connect failed: %s\n", mysqli_connect_error());
			exit();
		}	
		
		//$query = "SELECT chantier FROM gf_bdc WHERE dev_tva_affil = '".$_SESSION['ent_tva']."'";
		$query = "SELECT chantier FROM ".$tab_bdc." WHERE dev_tva_affil = '".$_SESSION['ent_tva']. "'";

	if ($result = $mysqli->query($query)) {
    	// fetch associative array
    	while ($row = $result->fetch_assoc()) {
			$listeChantiers = $listeChantiers."".$row['chantier'].", ";
			
   		}
		$listeChantiers = $listeChantiers."";
   		 // free result set
    	$result->free();
	}
			
			?>			
                
		

<script type="text/javascript">
  $(function() {
    var availableTags = [<?php echo $listeChantiers;?>];
    $( "#nomChantier" ).autocomplete({
      source: availableTags
    });
  });
  
  
  </script>


  
  
  
  
  

</form> 
</div>
</body>
</html>
