<?php
session_start();
require("dompdf-1/dompdf_config.inc.php");

function creerFichier($fichierChemin, $fichierNom, $fichierExtension, $fichierContenu, $droit=""){
$fichierCheminComplet = $_SERVER["DOCUMENT_ROOT"].$fichierChemin."/".$fichierNom;
if($fichierExtension!=""){
$fichierCheminComplet = $fichierCheminComplet.".".$fichierExtension;
}
 
// création du fichier sur le serveur
$leFichier = fopen($fichierCheminComplet, "wb");
fwrite($leFichier,$fichierContenu);
fclose($leFichier);
 
// la permission
if($droit==""){
$droit="0777";
}
 
// on vérifie que le fichier a bien été créé
$t_infoCreation['fichierCreer'] = false;
if(file_exists($fichierCheminComplet)==true){
$t_infoCreation['fichierCreer'] = true;
}
 
// on applique les permission au fichier créé
$retour = chmod($fichierCheminComplet,intval($droit,8));
$t_infoCreation['permissionAppliquer'] = $retour;
 
return $t_infoCreation;
}

// On crée notre fichier html de facture

$fichierChemin = "/";
$fichierNom = "fact_date_numfact";
$fichierExtension = "html";
$fichierContenu = $_SESSION['facture_htm'];
$droit = "0777";
$t_infoCreation = creerFichier($fichierChemin, $fichierNom, $fichierExtension, $fichierContenu, $droit);

// Et maintenant on s'occupe de PDF



$dompdf = new DOMPDF();
$dompdf->load_html($_SESSION['facture_htm']); 
//$dompdf->load_html('sdfksdhfsqjhfjdsk'); 
// d'autres formats sont dispo, il est aussi possible de définir un format en "pt"
$dompdf->set_paper("a4", "pt"); 
$dompdf->render(); 
// Si vous voulez le faire télécharger par le navigateur
$dompdf->stream("document_test.pdf", array("Attachment" => true));
// OU si vous voulez le mettre dans un ficher sur le serveur
// file_put_contents("document.pdf", $dompdf->output());

?>