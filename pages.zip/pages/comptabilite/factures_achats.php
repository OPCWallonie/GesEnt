<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>Gestion des factures d'achat</title>
<meta name="keywords" content="" lang="fr">
<meta name="description" content="">

<meta http-equiv="Content-Language" content="fr">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<!--[if IE]><script language="javascript" type="text/javascript" src="http://www.wuro.fr/static/js/excanvas.js"></script><![endif]-->	

<link rel="stylesheet" type="text/css" href="index.css" media="all">
</head>
<body>

<?php
include ("./menu.php");
?>

<div id="contenant">
		


<div class="box">
	<h2>Gestion des factures d'achat</h2>
	<ul id="menu">        <li>
			<a class="active" href="" rel="factures_list">
				<img src="../images/order-history64.png" alt="Liste des factures"> 
				<span>Liste des factures</span>
			</a>
        </li>
                <li>
			<a href="../comptabilite/ajouter_une_facture_-_achats.html" rel="factures_add">
				<img src="../images/order-history64.png" alt="Ajouter une facture"> 
				<span>Ajouter une facture</span>
			</a>
        </li>
        </ul>	
	
		
	<div id="factures_list" class="content">
				<form action="" method="get" class="search">
				                <div class="fleft">
	            <label for="date">Date :</label> <input class="textfield datepicker hasDatepicker" id="date" name="date" value="" type="text"></div><div class="fleft">
	            <label for="montant">Montant :</label> <input id="montant" name="montant" class="textfield number" value="" type="text"> €</div>
                <div class="fleft"> 
	            <label for="inputString">Désignation :</label> <input autocomplete="off" name="designation" class="textfield string" id="inputString" value="" type="text">
	            		<div class="suggestionsBox" id="suggestions" style="left: 80px;">
							<img src="../images/uparrow.png" alt="upArrow">
							<div class="suggestionList" id="autoSuggestionsList">
								&nbsp;
							</div>
							<div class="hide">factures_achat/autoCompleteDesignation</div>
						</div>
					
                </div>
                <div class="fleft">
	            <select name="mode_paiement"><option value="">Modes de paiement</option></select>			
</div>
				
				<a href="#" class="button submit"><span><img src="../images/magnifier.png" alt="Recherche">Rechercher</span></a>
				
			</form>
			
			
		<table cellspacing="0">
			<tbody><tr>
				<th width="70">Facture</th>
				<th class="aleft" width="80">Date</th>
				<th class="aright" width="120">Prix</th>
				<th>Désignation</th>
				<th class="aleft" width="180">Mode de paiement</th>
				<th width="16"></th>
			</tr>
			
		<tr><td colspan="6">Aucune facture d'achat n'a été créée</td></tr>			</tbody></table>
		
	</div>
	
	<div id="factures_add" class="content hide">
					
		<form id="ajouter_facture_achat" method="post" action="" enctype="multipart/form-data">
						<fieldset>
			<p class="gris01">
				<span class="toolTip" title="Le mois et l'année qui s'affichent par défaut servent à l'export de vos factures d'achat. Vous pouvez les modifier pour inclure la facture sur le mois précédent uniquement si vous n'avez pas encore effectué l'export du mois précédent">&nbsp;</span>
				<label for="date_export">Mois - Année :</label>
				<span id="span_date_export_mois">11</span>&nbsp;-&nbsp;<span id="span_date_export_annee">2012</span>
				<a href="#" id="modifier_date_export" style="margin-left:20px;text-decoration:underline;">Modifier</a>
				<input name="mois" id="date_export_mois" value="11" type="hidden">
				<input name="annee" id="date_export_annee" value="2012" type="hidden">
            </p>
			<p>
				<span class="toolTip" title="Date à laquelle l'achat a été effectué">&nbsp;</span>
				<label for="date_achat">Date d'achat : </label>
				<input name="date_achat" id="date_achat" class="textfield datepicker hasDatepicker" value="" type="text">
			</p>

			<p class="gris01">
				<span class="toolTip" title="L'ajout ou la modification des moyens de paiement est possible dans Préférences - Rubrique Paramètres avancés - Modes de paiement">&nbsp;</span>
				<label for="mode_reglement">Réglement : </label>
				<select name="mode_reglement" id="mode_reglement">
 					<option style="background-color: rgb(227, 227, 227);" value="Chèque">Chèque</option><option value="Carte bancaire">Carte bancaire</option><option style="background-color: rgb(227, 227, 227);" value="Virement">Virement</option>				</select>
			</p>
			<p>
				<span class="toolTip" title="Les achats sont classés par types, il vous appartient de renseigner les types d'achat (par exemple : Honoraires, Sous-traitance, Voyage et déplacement) pour cela cliquez sur le bouton &quot;Ajouter un type&quot;">&nbsp;</span>
				<label for="type_facture">Type : </label>
				<select name="type_facture" id="type_facture">
                	<option value="">Aucun</option>
 									</select>
				<a href="" rel="shadowbox;width=400;height=220" class="button"><span><img src="../images/add.png" alt="Ajouter">Ajouter un type</span></a>
			</p>


			<div class="gris01" style="clear: both; height: auto; line-height: 25px; min-height: 25px; padding: 5px;">
				<span class="toolTip" title="Le code fournisseur est propre à chaque fournisseur <br />
Vous pouvez attribuer un code fournisseur lorsque vous ajoutez un contact appartenant à la catégorie Fournisseurs, pour cela il faut se rendre dans le module Contacts - Ajouter - et renseigner le champ Code contact" style="margin-top: 4px;">&nbsp;</span>
				<label for="achat_code_client">Code compta : </label>
				
				<input autocomplete="off" class="textfield" name="client" id="achat_code_client" value="" type="text">
				<div class="suggestionsBox" id="suggestions_achat_code_client" style="left: 195px;">
					<img src="../images/uparrow.png" alt="upArrow">
					<div class="suggestionList" id="autoSuggestionsList_achat_code_client">&nbsp;</div>
					<div class="hide">contacts/autoCompleteCodeClient</div>
				</div>
			</div>
			 							

			<p>
				<span class="toolTip" title="Indiquez ici le nom du fournisseur">&nbsp;</span>
				<label for="fournisseur">Fournisseur : </label>
				<input name="fournisseur" id="fournisseur" class="textfield" value="" type="text">
			</p>
			<p class="gris01">
				<span class="toolTip" title="Renseignez ce champ lorsque vous êtes facturé d'un service sur une période définie (ex : 1er trimestre 2011)">&nbsp;</span>
				<label for="periode">Période : </label>
				<input name="periode" id="periode" class="textfield" value="" type="text">
			</p>
			<p>
				<span class="toolTip" title="Précisez ici le produit ou service acheté. Evitez les majuscules">&nbsp;</span>
				<label for="achat_nom">Désignation : </label>
				<input name="achat_nom" id="achat_nom" class="textfield" value="" type="text">
			</p>
			<p class="gris01">	
				<span class="toolTip" title="Indiquez le numéro inscrit sur votre facture d'achat">&nbsp;</span>
				<label for="num_facture">Numéro de facture : </label>
				<input name="num_facture" id="num_facture" class="textfield" value="" type="text">
			</p>
			<p>
				<span class="toolTip" title="Montant HT de la facture d'achat. Vous pouvez indiquer les décimales">&nbsp;</span>
				<label for="montant_achat_ht">Montant HT : </label>
				<input name="montant_achat_ht" id="montant_achat_ht" class="textfield" style="width: 80px;" value="" type="text"> €
			</p>
			<p class="gris01">
				<span class="toolTip" title="Montant TTC de la facture d'achat. Vous pouvez indiquer les décimales">&nbsp;</span>
				<label for="montant_achat_ttc">Montant TTC : </label>
				<input name="montant_achat_ttc" id="montant_achat_ttc" class="textfield" style="width: 80px;" value="" type="text"> €
			</p>
			<p>
				<span class="toolTip" title="Cliquez sur le bouton Parcourir pour intégrer la facture d'achat">&nbsp;</span>
				<label for="fichier">Fichier : </label>
				<input name="fichier" id="fichier" type="file">
			</p>
            </fieldset>
						<p class="acenter gris01">
				<a href="#" class="button submit"><span><img src="../images/accept.png" alt="Ajouter">Ajouter cette facture</span></a>
			</p>
		</form>	</div>
	
	
	
	
</div></div>

<?php
include('./footer.php');
?>

</body>
</html>
