<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>Gestion des factures d'achat</title>
<meta name="keywords" content="" lang="fr">
<meta name="description" content="">

<meta http-equiv="Content-Language" content="fr">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<!--[if IE]><script language="javascript" type="text/javascript" src="http://www.wuro.fr/static/js/excanvas.js"></script><![endif]-->	

<link rel="stylesheet" type="text/css" href="../css/facture_achat_ajout.css" media="all" />
<link type="text/css" href="../css/datepicker2.css" rel="stylesheet" />

<script language="javascript">
$('#date_achat').live('click', function(e) {
   e.preventDefault();
   $(this).attr("autocomplete", "off");  
});

 $(document).ready(function() {
 	$( "#date_achat").datepicker({  
            inline: true,  
            showOtherMonths: true,  
            dayNamesMin: ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'],  
        });
 });
</script>
</head>
<body>

<?php
include ("./menu.php");
?>

<div id="contenant">
		


<div class="box">
	<h2>Gestion des factures d'achat</h2>
	<ul id="menu">        <li>
			<a class="" href="../comptabilite/factures_achats.html" rel="factures_list">
				<img src="../images/order-history64.png" alt="Liste des factures"> 
				<span>Liste des factures</span>
			</a>
        </li>
                <li>
			<a class="active" href="" rel="factures_add">
				<img src="../images/order-history64.png" alt="Ajouter une facture"> 
				<span>Ajouter une facture</span>
			</a>
        </li>
        </ul>	
	
		
	
	<div style="display: block;" id="factures_add" class="content hide">
					
		<form id="ajouter_facture_achat" method="post" action="" enctype="multipart/form-data">
						<fieldset>
			<p class="gris01">
            <span class="toolTip" title="Afin de pouvoir déterminer par chantier quels sont les couts réels, veuillez ici indiquer à quel site/devis se rapporte cette facture d'achat">&nbsp;</span>
            <label for="reference">Référence au chantier :</label>
            <input type="text" id="nomChantier" name="nomChantier" />
            </p>
            
			<p>
				<span class="toolTip" title="Date à laquelle l'achat a été effectué">&nbsp;</span>
				<label for="date_achat">Date de la facture : </label>
				<input name="date_achat" id="date_achat" value="" type="text" autocomplete="off" />
			</p>

			
			<p class="gris01">
				<span class="toolTip" title="Indiquez ici le nom du fournisseur">&nbsp;</span>
				<label for="fournisseur">Fournisseur : </label>
				<input name="fournisseur" id="fournisseur" class="textfield" value="" type="text">
			</p>
			
			<p>
				<span class="toolTip" title="Précisez ici le produit ou service acheté. Evitez les majuscules">&nbsp;</span>
				<label for="achat_nom">Désignation : </label>
				<input name="achat_nom" id="achat_nom" class="textfield" value="" type="text">
			</p>
            
			<p class="gris01">	
				<span class="toolTip" title="Indiquez le numéro inscrit sur votre facture d'achat">&nbsp;</span>
				<label for="num_facture">Numéro de facture : </label>
				<input name="num_facture" id="num_facture" class="textfield" value="" type="text">
			</p>
			<p>
				<span class="toolTip" title="Montant HT de la facture d'achat. Vous pouvez indiquer les décimales">&nbsp;</span>
				<label for="montant_achat_ht">Montant HT : </label>
				<input name="montant_achat_ht" id="montant_achat_ht" class="textfield" style="width: 80px;" value="" type="text"> €
			</p>
			<p class="gris01">
				<span class="toolTip" title="Montant TTC de la facture d'achat. Vous pouvez indiquer les décimales">&nbsp;</span>
				<label for="montant_achat_ttc">Montant TTC : </label>
				<input name="montant_achat_ttc" id="montant_achat_ttc" class="textfield" style="width: 80px;" value="" type="text"> €
			</p>
			<p>
				<span class="toolTip" title="Cliquez sur le bouton Parcourir pour intégrer la facture d'achat">&nbsp;</span>
				<label for="fichier">Fichier : </label>
				<input name="fichier" id="fichier" type="file">
			</p>
            </fieldset>
						<p class="acenter gris01">
				<a href="#" class="button submit"><span><img src="../images/accept.png" alt="Ajouter">Ajouter cette facture</span></a>
			</p>
		</form>	</div>
	
	
	
	
</div></div>

<?php
include('./footer.php');
?>

</body>

<?php			
		// Je me connecte
		$mysqli = new mysqli($db_host,$db_login,$db_pass,$db_base);
		// check connection 
		if (mysqli_connect_errno()) {
			printf("Connect failed: %s\n", mysqli_connect_error());
			exit();
		}	
		
		//$query = "SELECT chantier FROM gf_bdc WHERE dev_tva_affil = '".$_SESSION['ent_tva']."'";
		$query = "SELECT chantier FROM ".$tab_bdc." WHERE dev_tva_affil = '".$_SESSION['ent_tva']. "'";

	if ($result = $mysqli->query($query)) {
    	// fetch associative array
    	while ($row = $result->fetch_assoc()) {
			$listeChantiers = $listeChantiers."".$row['chantier'].", ";
			
   		}
		$listeChantiers = $listeChantiers."";
   		 // free result set
    	$result->free();
	}
			
			?>			
                
		

<script type="text/javascript">
  $(function() {
    var availableTags = [<?php echo $listeChantiers;?>];
    $( "#nomChantier" ).autocomplete({
      source: availableTags
    });
  });
  
  
  </script>




</html>
