<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="../css/facture.css" media="all">
</head>

<body>
<?php
include ("./menu.php");

if (isset($_SESSION[fact_data]))
{
unset($_SESSION[fact_data]);
}
?>


<div id="contenant">
		<span class="hide" id="type_doc">factures</span>
        <span class="hide" id="type_document">factures</span>




<div class="box">
	<h2>Gestion des factures</h2>
	
	<!--###############################################################
	############################# MENU ################################
	###############################################################-->
   
    		<ul id="menu">
        	        		<li>
		        						<a href="" rel="factures_list" class="active">
						<img src="../images/order-history64.png" alt="Liste des factures"> 
						<span>Liste des factures</span>
					</a>
        					</li>
			
							<li>
					<a href="../comptabilite/ajouter_une_facture.html" rel="facture_add">
						<img src="../images/ordering64.png" alt="Créer une nouvelle facture">
						<span>Ajouter une facture</span>
					</a>
							</li>
						
        	
			    	</ul>
    



	<div id="factures_list" class="content">
						<form action="" method="get" id="form_recherche_devis" class="search">
												 					<div class="fleft">
							<label for="src_date_devis">Date : </label>
							<input name="date" id="src_date_devis" class="textfield datepicker hasDatepicker" value="" type="text">
                        </div>
                        <div class="fleft">
						<label for="src_montant">Montant : </label><input class="textfield number" name="montant" id="src_montant" value="" type="text"> €
                        </div>
						
												
						 <div class="fleft">
							<select name="categorie" id="src_categorie_devis">
								<option value="">Catégories</option>
								<option style="background-color: rgb(227, 227, 227);" value="865">Défaut</option>							</select> 
							</div>
                            <div class="fleft">	
							<select name="etat" id="src_etat">
								<option value="">Tous états</option>
								
								<option style="background-color: rgb(227, 227, 227);" value="Pro Forma">Pro Forma</option>
								
								<option value="En attente">En attente</option>
								
								<option style="background-color: rgb(227, 227, 227);" value="Impayée">Impayée</option>

								<option value="Payée">Payée</option>
								
								<option style="background-color: rgb(227, 227, 227);" value="Retard">Retard</option>
						
							</select>
							</div>
                            <div class="fleft">
						 
						
							 <select name="moyen_paiement" id="moyen_paiement">
							 	<option value="">Moyens de paiement</option><option style="background-color: rgb(227, 227, 227);" value="Virement">Virement</option>							 </select>
							</div>
						 <a href="#" class="button submit"><span><img src="../images/magnifier.png" alt="Recherche">Rechercher</span></a>
		
				
					
						<span><a href="#" class="button bouton_deroulant"><span><img src="../images/advanced_search.png" alt="Recherche avancée"> Avancée</span></a></span>
					
					<div class="hide" id="form_recherche_avancee">
						<div class="fleft">
                            <label for="src_reference_devis">N° Facture : </label><input autocomplete="off" name="ref" id="src_reference_devis" class="textfield code" value="" type="text">
                                <div class="suggestionsBox" id="suggestions_reference" style="left: 75px;">
                                    <img src="../images/uparrow.png" alt="upArrow">
                                    <div class="suggestionList" id="autoSuggestionsList_reference">
                                        &nbsp;
                                    </div>
                                    <div class="hide">factures/autoCompleteRef</div>
                                </div> 
							</div>
                            <div class="fleft">
							<label for="src_code_client">Code client : </label><input autocomplete="off" name="code_client" value="" class="textfield code" id="src_code_client" type="text"> 
						
							<div class="suggestionsBox" id="suggestions_code_client_devis" style="left: 78px;">
								<img src="../images/uparrow.png" alt="upArrow">
								<div class="suggestionList" id="autoSuggestionsList_code_client_devis">&nbsp;</div>
								<div class="hide">factures/autoCompleteCodeClient</div>
							</div> 
                            </div>
						 <div class="fleft">
						<label for="src_client">Client : </label><input autocomplete="off" class="textfield string" name="client" id="src_client" value="" type="text"> 							
						
							<div class="suggestionsBox" id="suggestions_client_devis" style="left: 47px;">
								<img src="../images/uparrow.png" alt="upArrow">
								<div class="suggestionList" id="autoSuggestionsList_client_devis">&nbsp;</div>
								<div class="hide">factures/autoCompleteClient</div>
							</div>
                            </div>
														<div class="fleft">
							<label for="disp_avoir">Avoirs</label> <input name="dispavoir" id="disp_avoir" class="checkbox" type="checkbox">
                            </div>
							 
				
						
						<a href="#" class="button submit" id="bouton_recherche_avancee"><span>Rechercher</span></a>
					</div>
				</form>

												
				<table cellspacing="0">
					<tbody><tr>
                    	<th width="100">&nbsp;</th>
						<th class="aleft" width="80"><a href="http://cscpl.wuro.fr/manager/factures?tri=num&amp;order=a">▲ Numéro</a></th>
						<th width="80"><a href="http://cscpl.wuro.fr/manager/factures?tri=date&amp;order=d">▼ Date</a></th>
						<th width="140"><a href="http://cscpl.wuro.fr/manager/factures?tri=interlocuteur&amp;order=d">▼ Interlocuteur</a></th>
						<th class="aleft" width="140"><a href="http://cscpl.wuro.fr/manager/factures?tri=client&amp;order=d">▼ Client</a></th>
						<th width="120"><a href="http://cscpl.wuro.fr/manager/factures?tri=montant&amp;order=d">▼ Montant</a></th>
						<th width="100"><a href="http://cscpl.wuro.fr/manager/factures?tri=etat&amp;order=d">▼ Etat</a></th>
						<th width="45"></th>
					</tr>
							
				<tr class="alternate" id="lig64892">
									<td class="vtop">
									</td>
									<td class="vtop numero">2012110001</td>
									<td class="vtop">14/11/2012</td>
									<td class="vtop acenter gris">Administrateur </td>
									<td>La societe...<br><span class="legende">(Code client : code compta)</span></td>
									<td class="vtop aright">40.2 € HT<br>-11.86 € TTC</td>
									<td class="vtop aleft"><select name="" class="select_etat"><option value="Brouillon">Brouillon</option><option value="En attente">En attente</option><option value="Impayée">Impayée</option><option value="Payée">Payée</option><option>Retard</option></select></td>
									
									<td class="vtop">			<a href="http://cscpl.wuro.fr/manager/factures/index/64892#_facture_add" title="Modifier"><img src="../images/pencil.png" alt="Modifier" class="inline"></a>
										<a href="http://cscpl.wuro.fr/manager/factures/html/C54DCE1D5A7C334848CD9DEC24B698C9/0" onclick="window.open(this.href);return false;" title="Imprimer" style="margin-left: 8px;"><img src="../images/printer.png" alt="Imprimer" class="inline"></a>
									</td>
								</tr></tbody></table>			
	</div>
	
	
	

	<div id="externes_list" class="content hide">
			</div>
	
	
		
		<div id="facture_add" class="hide content">
					</div>	
		
	
	
	
	
</div>
</div>









</div>
<?php
include('./footer.php');
?>

</body>
</html>