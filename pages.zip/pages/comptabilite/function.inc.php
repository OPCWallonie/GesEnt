<?php
/* 		FormatDate		: Ligne 12
		Majdata 		: Ligne 21  	: Arguments : $total_net
		Recdata 		: Ligne 62 		: Arguments : $total_net, $etat
		Initdevnum		: Ligne 231		: Arguments : /
		Initbdcnum		: Ligne 296		: Arguments : /
		Initannexenum	: Ligne	340		: Arguments : $inherit
*/		



function FormatDate()
{
	$annee = substr($_SESSION['infos_generales']['dateVal'], 6, 4); 
 $mois = substr($_SESSION['infos_generales']['dateVal'], 3, 2); 
 $jour = substr($_SESSION['infos_generales']['dateVal'], 0, 2);  
 $_SESSION['infos_generales']['dateVal'] = $annee . '-' . $mois . '-' . $jour; 
}


function Majdata($total_net)
{	
	FormatDate();
// Ici je serialise les données de ma facture
	$factDataSerial = serialize($_SESSION['fact_data']);		
				

	$sql = "UPDATE gf_".$_SESSION['infos_generales']['origine']." 
	SET 
		dev_tva_affil='".$_SESSION['ent_tva']."', 
		dev_frais_de_port='".$_SESSION['infos_generales']['frais_de_port']."', 
		dev_nomClient='".mysql_real_escape_string($_SESSION['infos_generales']['nomClient'])."',
		dev_adresseClient='".mysql_real_escape_string($_SESSION['infos_generales']['adresse'])."',
		dev_codePostal='".$_SESSION['infos_generales']['code_postal']."',
		dev_ville='".mysql_real_escape_string($_SESSION['infos_generales']['ville'])."', 
		dev_pays='".$_SESSION['infos_generales']['pays']."', 
		tvaClient='".$_SESSION['infos_generales']['tva_intra']."', 
		dev_codeClient='".$_SESSION['infos_generales']['code_client']."', 
		dev_mailClient='".$_SESSION['infos_generales']['mail_client']."', 
		dev_modeReglement='".$_SESSION['infos_generales']['mode_reglement']."',
		dev_etatPayement='".$_SESSION['infos_generales']['etat_payement']."',
		dev_factDate='".$_SESSION['infos_generales']['fact_date']."',
		dev_cocontract='".$_SESSION['infos_generales']['cocontractants']."',
		dev_notes='".mysql_real_escape_string($_SESSION['infos_generales']['notes'])."',
		dev_aCompte='".$_SESSION['infos_generales']['acompte']."',
		dev_ristourneGlobale='".$_SESSION['infos_generales']['ristourne_globale']."',
		dev_delaiReglement='".$_SESSION['infos_generales']['delai_reglement']."',
		dev_dateValidite='".$_SESSION['infos_generales']['dateVal']."',
		dev_serialize='".mysql_real_escape_string($factDataSerial)."',
		tva='".$_SESSION['infos_generales']['tva']."',
		montant='".$total_net."',
		chantier='".mysql_real_escape_string($_SESSION['infos_generales']['chantier'])."'		
	WHERE id = '".$_SESSION['infos_generales']['id']."'";
	
	mysql_query('set names utf8');
	mysql_query($sql) or die('Erreur SQL !'.$sql.'<br>'.mysql_error());					
	mysql_close();			
}




function Recdata($total_net, $etat)
{
	FormatDate();
// Ici je serialise les données de ma facture
				$factDataSerial = serialize($_SESSION['fact_data']);
				
				
				echo $tab_infos;
				
				// ( qd je dis id c'est bien le numéro de la pièce en traitement )Vu que l'id de ma facture je l'ai déjà trouvé avant, je peux vérifier si l'utilisateur n'essaye pas de ré-enregistrer une même facture... le cas échéant, on défini l'actio comme update... Ainsi j'évite le double enregistrement. Si par contre id+1 trouvé auparavant n'est pas = à id+1 lu à l'instant, alors c'est qu'il y a 2 utilisateurs qui encodent une facture => BIEN Incrémenter le nouveau num de dev/fact/bdc de 1 !!!
				
				
				
				
				// Ici je pose la condition : Si il a un "actio" défini dans la variable de session alors il s'agit d'un update et pas d'un nouvel enregistrement
				
				if (isset($_SESSION['devis_data']['actio']) || isset($_SESSION['bdc_data']['actio']) || isset($_SESSION['facture_data']['actio']))
				{
					// Je mets à jour
				}
				else
				{
					$date = date("d-m-Y");
					
					// Je vais vérifier qu'il ne s'agit pas d'une annexe => j'explode le numéro de doc ET je regarde si un paramètre 3 existe...
					$chaineSplitee = explode('/', $_SESSION['infos_generales']['bdcNum']);
					
					if($chaineSplitee['3'] == '')
					{
						
						
					// J'incrémente le n° de devis/facture/bdc de 1
					switch ($_SESSION['infos_generales']['origine']) {
						
						case "devis":
							$chaineSplitee = explode('/', $_SESSION['devNumLast']);
							$chaineSplitee['2']++;
							if (strlen($chaineSplitee['2'])<4)
							{
								$zerosARajouter	= 4 - strlen($chaineSplitee['2']);
								for ($i; $i<$zerosARajouter; $i++)
								{
									$zeros = '0'.$zeros;
								}
							}
							
							$_SESSION['devNumLast'] = 'DEV/'.$chaineSplitee['1'].'/'.$zeros.$chaineSplitee['2'];
							$_SESSION['infos_generales']['devNum'] = $_SESSION['devNumLast'];
							$sql = "UPDATE gf_infospratiques 
									SET 
									devNumLast='".$_SESSION['devNumLast']."' 
									WHERE ent_tva = '".$_SESSION['ent_tva']."'";
							break;
							
						case "facture":
							
							$chaineSplitee = explode('/', $_SESSION['factNumLast']);
							$chaineSplitee['2']++;
							if (strlen($chaineSplitee['2'])<4)
							{
								$zerosARajouter	= 4 - strlen($chaineSplitee['2']);
								for ($i; $i<$zerosARajouter; $i++)
								{
									$zeros = '0'.$zeros;
								}
							}
							
							$_SESSION['factNumLast'] = 'FAC/'.$chaineSplitee['1'].'/'.$zeros.$chaineSplitee['2'];
							$_SESSION['infos_generales']['factNum'] = $_SESSION['factNumLast'];
							$sql = "UPDATE gf_infospratiques 
									SET 
									factNumLast='".$_SESSION['factNumLast']."' 
									WHERE ent_tva = '".$_SESSION['ent_tva']."'";
							break;
							
						case "bdc":
						
							$chaineSplitee = explode('/', $_SESSION['bdcNumLast']);
							$chaineSplitee['2']++;
							if (strlen($chaineSplitee['2'])<4)
							{
								$zerosARajouter	= 4 - strlen($chaineSplitee['2']);
								for ($i; $i<$zerosARajouter; $i++)
								{
									$zeros = '0'.$zeros;
								}
							}
							
							$_SESSION['bdcNumLast'] = 'BDC/'.$chaineSplitee['1'].'/'.$zeros.$chaineSplitee['2'];
							$_SESSION['infos_generales']['bdcNum'] = $_SESSION['bdcNumLast'];
							$sql = "UPDATE gf_infospratiques 
									SET 
									bdcNumLast='".$_SESSION['bdcNumLast']."' 
									WHERE ent_tva = '".$_SESSION['ent_tva']."'";
							break;	
								
													}
					// ET update l'info dans infosgenerales
				
				
				mysql_query($sql) or die('Erreur SQL !'.$sql.'<br>'.mysql_error());
					
					
					
					} // Fin de mon if afin de vérifier qu'il ne s'agit pas d'une annexe :)
					else // Sinon je sais que je peux mettre a jour le document mère afin d'y ajouter les annexes
					{
						$_SESSION['infos_generales']['annexes_id'] = $_SESSION['infos_generales']['annexes_id'].'/'.$chaineSplitee['3'];
						$sql = "UPDATE gf_bdc 
								SET 
								annexes_id = '".$_SESSION['infos_generales']['annexes_id']."' 
								WHERE id = ".$_SESSION['infos_generales']['document_mere'];
								mysql_query($sql) or die('Erreur SQL !'.$sql.'<br>'.mysql_error());
						
					}
													
													
													
					
					// Je crée un nouvel enregistrement
					$aInserer = "INSERT INTO gf_".$_SESSION['infos_generales']['origine']."  (id, 
					dev_tva_affil, 
					dev_num,
					bdc_num,
					fact_num,
					annexes_id, 
					dateDoc,
					dev_frais_de_port, 
					dev_nomClient,  
					dev_adresseClient, 
					dev_codePostal, 
					dev_ville, 
					dev_pays, 
					tvaClient, 
					dev_codeClient, 
					dev_mailClient, 
					dev_modeReglement,
												dev_etatPayement,
												dev_factPayee,
												dev_factDate,
												dev_cocontract,
												dev_notes,
												dev_aCompte,
												dev_ristourneGlobale,
												dev_delaiReglement,
												dev_dateValidite,
												dev_serialize,
												tva,
												montant, 
												etat,
												chantier) 
					VALUES
												('',
												'".$_SESSION['ent_tva']."',
												'".$_SESSION['infos_generales']['devNum']."',
												'".$_SESSION['infos_generales']['bdcNum']."',
												'".$_SESSION['infos_generales']['factNum']."',
												'".$_SESSION['infos_generales']['annexes_id']."',
												'".$_SESSION['infos_generales']['dateDoc']."',
												'".$_SESSION['infos_generales']['frais_de_port']."',
												'".mysql_real_escape_string($_SESSION['infos_generales']['nomClient'])."',
												'".mysql_real_escape_string($_SESSION['infos_generales']['adresse'])."',
												'".$_SESSION['infos_generales']['code_postal']."',
												'".mysql_real_escape_string($_SESSION['infos_generales']['ville'])."',
												'".$_SESSION['infos_generales']['pays']."',
												'".$_SESSION['infos_generales']['tva_intra']."',
												'".$_SESSION['infos_generales']['code_client']."',
												'".$_SESSION['infos_generales']['mail_client']."',
												'".$_SESSION['infos_generales']['mode_reglement']."',
												'".$_SESSION['infos_generales']['etat_payement']."',
												'',
												'".$date."',
												'".$_SESSION['infos_generales']['cocontractants']."',
												'".mysql_real_escape_string($_SESSION['infos_generales']['notes'])."',
												'".$_SESSION['infos_generales']['acompte']."',
												'".$_SESSION['infos_generales']['ristourne_globale']."',
												'".$_SESSION['infos_generales']['delai_reglement']."',
												'".$_SESSION['infos_generales']['dateVal']."',
												'".mysql_real_escape_string($factDataSerial)."',
												'".$_SESSION['infos_generales']['tva']."',
												'".$total_net."',
												'".$etat."',
												'".mysql_real_escape_string($_SESSION['infos_generales']['chantier'])."'
												)";
				
				// On effectue l'insertion
				mysql_query('set names utf8');
				mysql_query($aInserer) or die('Erreur SQL !'.$aInserer.'<br>'.mysql_error());	
				mysql_close();
				}
}


function Initdevnum()
{

// On va déterminer quel sera le numéro de document... Vu que je pars sur un numéro "DEV/2013/0001" je prends la valeur de 2013 et je vérifie que le dernier nombre était déjà bien en 2013 ( passage à la nouvelle année ) si c'est le cas on incrémente simplement de 1 le dernier numéro de devis stocké dans $_SESSION['devNumLast'].
// SI par contre l'année est nouvelle, alors on change l'année et le numéro est remis à 1...
// Première chose : Spliter mon numéro de devis afin d'isoler l'année et le numéro de devis

// PS : Ne pas oublier d'incrémenter $_SESSION['devNumLast'] lors de la sauvegarde au cas où il encoderait plusieurs devis dans la même session... C'est OK...
$chaineSplitee = explode('/', $_SESSION['devNumLast']);

// Si jamais nous avons a faire au 1er devis d'un nouvel utilisateur

	if ($chaineSplitee['1'] != date('Y')) // Si l'année en cours est différente alors...
	{
		$chaineSplitee['1'] = date('Y'); // L'année devient celle en cours
		$chaineSplitee['2'] = '0001'; // Le numéro est remis à 0
		
	}
	else
	{
	$chaineSplitee['2']++; // Sinon on incrémente simplement le numéro de 1...
	// Le problème c'est qu'il ne va afficher que le nombre sans les 0, on doit donc rajouter ce qu'il faut...
	if (strlen($chaineSplitee['2'])<4)
		{
		$zerosARajouter	= 4 - strlen($chaineSplitee['2']);
		for ($i; $i<$zerosARajouter; $i++)
			{
				$zeros = '0'.$zeros;
			}
		}
		
	
	}

	
$_SESSION['infos_generales']['devNum'] = 'DEV/'.$chaineSplitee['1'].'/'.$zeros.$chaineSplitee['2']; // Hop je replace le tout dans ma variable de session	

// Inscription de la date ( dateDoc ) vu qu'il s'agit d'un nouveau document...

$_SESSION['infos_generales']['dateDoc'] = date('d/m/Y');	
	
}	

function Initbdcnum()		
{

// On va déterminer quel sera le numéro de document... Vu que je pars sur un numéro "BDC/2013/0001" je prends la valeur de l'année ( 2013 ) et je vérifie que le dernier nombre était déjà bien en 2013 ( passage à la nouvelle année ) si c'est le cas on incrémente simplement de 1 le dernier numéro de devis stocké dans $_SESSION['bdcNumLast'].
// SI par contre l'année est nouvelle, alors on change l'année et le numéro est remis à 1...
// Première chose : Spliter mon numéro de bdc afin d'isoler l'année et le numéro de devis

// PS : Ne pas oublier d'incrémenter $_SESSION['bdcNumLast'] lors de la sauvegarde au cas où il encoderait plusieurs devis dans la même session... C'est OK...
$chaineSplitee = explode('/', $_SESSION['bdcNumLast']);

// Si jamais nous avons a faire au 1er devis d'un nouvel utilisateur

	if ($chaineSplitee['1'] != date('Y')) // Si l'année en cours est différente alors...
	{
		$chaineSplitee['1'] = date('Y'); // L'année devient celle en cours
		$chaineSplitee['2'] = '0001'; // Le numéro est remis à 0
		
	}
	else
	{
	$chaineSplitee['2']++; // Sinon on incrémente simplement le numéro de 1...
	// Le problème c'est qu'il ne va afficher que le nombre sans les 0, on doit donc rajouter ce qu'il faut...
	if (strlen($chaineSplitee['2'])<4)
		{
		$zerosARajouter	= 4 - strlen($chaineSplitee['2']);
		for ($i; $i<$zerosARajouter; $i++)
			{
				$zeros = '0'.$zeros;
			}
		}
		
	
	}

	
$_SESSION['infos_generales']['bdcNum'] = 'BDC/'.$chaineSplitee['1'].'/'.$zeros.$chaineSplitee['2']; // Hop je replace le tout dans ma variable de session	

// Inscription de la date ( dateDoc ) vu qu'il s'agit d'un nouveau document...

$_SESSION['infos_generales']['dateDoc'] = date('d/m/Y');	
	
}	


function Initannexenum($inherit){
	// J'utilise la forme xx/xx/xx/xx/xx/xx dans mon champs annexe_id de la base => j'explode le tout et je prends la derniere valeur du tableau afin d'incrémenter ça :)
	$tableau_annexes = explode('/',$_SESSION['infos_generales']['annexes_id']);
	$numAnnexe = end($tableau_annexes);
	$numAnnexe++;
	$_SESSION['infos_generales']['bdcNum'] = $inherit."/".$numAnnexe;
	
}


function verifProduit($mysqli, $designation) {
	
	$query = "SELECT * FROM gf_produits WHERE nomProduit LIKE '%".$designation."%' ";

	if ($result = $mysqli->query($query)) {
		$cnt=0;
    	/* fetch associative array */
    	while ($row = $result->fetch_assoc()) {
     	   $mesProduits[$cnt] = $row['nomProduit'];
			$cnt++;
   		 }

   		 /* free result set */
    	$result->free();
	}
	return $mesProduits;
	global $mesProduits;
	
}


function enregistreProduit($mysqli, $designation) {
	
	if ($stmt = $mysqli->prepare("INSERT INTO gf_produits (nomProduit) VALUES (?)")) {

		/* Bind our params */
		$stmt->bind_param('s', $designation);

		/* Execute the prepared Statement */
		$stmt->execute();
		
		/* Close the statement */
		$stmt->close();	
	}
	else {
		/* Error */
		printf("Prepared Statement Error: %s\n", $mysqli->error);
	}
	
	
	
}

function testDate( $value )
	{
		return preg_match( '`^\d{1,2}/\d{1,2}/\d{4}$`' , $value );
	}


?>