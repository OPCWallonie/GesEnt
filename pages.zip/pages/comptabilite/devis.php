<?php
// Session créée ? Sinon, en créer une nouvelle
if($PHPSESSID) session_start($PHPSESSID);
else session_start();

// Je vide mes variables de sessions m'ayant servi à créer mon document facture, devis ou bon de commande
	// Et maintenant je vide mes variables de session
				unset($_SESSION['fact_data']);
				unset($_SESSION['infos_generales']);
				unset($_SESSION['devis_data']);
				unset($_SESSION['bdc_data']);
				unset($_SESSION['facture_data']);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>Gestion des devis</title>
<meta name="keywords" content="" lang="fr">
<meta name="description" content="">

<meta http-equiv="Content-Language" content="fr">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<!--[if IE]><script language="javascript" type="text/javascript" src="http://www.wuro.fr/static/js/excanvas.js"></script><![endif]-->	


</head>
<body>



 <?php
include ("./menu.php");

// Pour notre recherche, je recharge ici les données éventuelles du $_GET...

$rechDate = $_GET['date'];
$rechMontant = $_GET['montant'];

$rechRef = $_GET['ref'];
$rechEtat = $_GET['etat'];

// Maintenant, si un n'est pas vide, alors on rajoute un critère de recherche

if (!empty($rechDate))
{
	// Les commentaires c'était pour mettre ma date au format AAAA-MM-JJ Mais vu que la base est à l'endroit, je ne fais rien... Cela dit je laisse l'option au cas où; en effet si je décide de changer la base, c'est déjà ça de pris :p
	
	//$newDate = explode('/', $rechDate);
	//$rechDate = $newDate['2'].'-'.$newDate['1'].'-'.$newDate['0'];
	$rechCritere = $rechCritere."AND dateDoc LIKE '%".$rechDate."%' ";
}
if (!empty($rechMontant))
{
	$rechMontant = str_replace(',', '.', $rechMontant); // Je remplace les caractères
	$rechCritere = $rechCritere."AND montant LIKE '%".$rechMontant."%' ";
}
if (!empty($rechRef))
{
	$rechCritere = $rechCritere."AND dev_num LIKE '%".$rechRef."%' ";
}
if (!empty($rechEtat))
{
	// On va maintenant vérifier qu'il ne s'agit pas de Dépassé... Auquel car le critère est différent. On doit faire une recherche sur les dates...
	if ($rechEtat == "Dépassé")
	{
		$rechCritere = $rechCritere."AND dev_dateValidite < CURDATE()";
	}
	else
	{
		$rechCritere = $rechCritere."AND etat LIKE '".$rechEtat."' ";
	}
}
if ($rechCritere == 'AND ') $rechCritere = '';



// Ici je vais accéder à ma liste de devis et stocker ses données dans une variable de session... Ca allégera la charge du serveur MySQL pour afficher les devis et même les modifier le cas échéant.	
mysql_query('set names utf8');		
// on crée la requete SQL
$sql_devis = "SELECT * FROM ".$tab_devis." WHERE dev_tva_affil = '".$_SESSION['ent_tva']. "' ".$rechCritere;  


// on envoie la requête 
$req_devis = mysql_query($sql_devis) or die('Erreur SQL !<br />'.$sql_devis.'<br />'.mysql_error()); 

$cnt = 0; // J'initialise un petit compteur
$montantTotal = 0; // J'initialise le montant total
$cntVal = 0;
unset($_SESSION['devis_data']);
unset($devis_data);
// Et maintennt je stocke dans une variable de session
while($data_devis = mysql_fetch_array($req_devis))  
    {	
		$devis_data[$cnt] = array( 				id => $data_devis['id'],
												dev_tva_affil => $data_devis['dev_tva_affil'],
												devNum => $data_devis['dev_num'],
												dateDoc => $data_devis['dateDoc'],
												frais_de_port => $data_devis['dev_frais_de_port'],
												nomClient => $data_devis['dev_nomClient'],
												adresse => $data_devis['dev_adresseClient'],
												code_postal => $data_devis['dev_codePostal'],
												ville => $data_devis['dev_ville'],
												pays => $data_devis['dev_pays'],
												tva_intra => $data_devis['tvaClient'], 
												code_client => $data_devis['dev_codeClient'],
												mail_client => $data_devis['dev_mailClient'],
												mode_reglement => $data_devis['dev_modeReglement'],
												etat_payement => $data_devis['dev_etatPayement'],
												fact_paye => $data_devis['dev_factPayee'],
												fact_date => $data_devis['dev_factDate'],
												ristourne_globale => $data_devis['dev_ristourneGlobale'],
												notes => $data_devis['dev_notes'],
												dateVal => $data_devis['dev_dateValidite'],
												cocontractants => $data_devis['dev_cocontract'],
												delai_reglement => $data_devis['dev_delaiReglement'],
												acompte => $data_devis['dev_aCompte'],
												dev_serialize => $data_devis['dev_serialize'],
												tva => $data_devis['tva'],
												montant => $data_devis['montant'],
												etat => $data_devis['etat'],
												date_etat => $data_devis['date_etat'],
												actio => ''
												);

$cnt++; // Et j'incrémente le tout 
$montantTotal = $montantTotal + $data_devis['montant'];
												
// Je vais vérifier maintenant que la date de Validité du devis n'est pas dépassée sinon je transforme ça en état "Refusé"... 

// date à tester : 
$now = date('Y-m-d'); 

// Orientation Object 
$now = new DateTime( $now ); 
$now = $now->format('Ymd'); 
$next = new DateTime( $data_devis['dev_dateValidite'] ); 
$next = $next->format('Ymd'); 


// Test
if( $now > $next  && $etat != "Refusé" && $etat != "Validé") 
{	
	$requete = "UPDATE gf_devis 
				SET etat='Refusé'
				WHERE id = '".$data_devis['id']."'";
	
	mysql_query('set names utf8');
	mysql_query($requete) or die('Erreur SQL !'.$requete.'<br />'.mysql_error());					
				
	
}

										
												
		
	
		if ($data_devis['etat'] == "Validé")
		{
			$cntVal++;
			$montantValide = $montantValide + $data_devis['montant'];
		}
		
		 
	}
$_SESSION['devis_data'] = $devis_data;	



?>




<div id="contenant">
		<span class="hide" id="type_doc">devis</span>
        <span class="hide" id="type_document">devis</span>



<div class="box">
	<h2>Gestion des devis</h2>
	
	<!--###############################################################
	############################# MENU ################################
	###############################################################-->
   <ul id="menu">        <li>
			<a class="active" href="../comptabilite/devis.html" rel="devis_list"><img src="../images/order-history64.png" alt="Liste des devis"> <span>Liste des devis</span></a>
        </li>
			
			<li>
				<a href="../comptabilite/ajouter_un_devis.html" rel="devis_add"><img src="../images/ordering64.png" alt="Créer un nouveau devis"> <span>Ajouter un devis</span></a>
			</li>
		</ul>   
    
    

	<div id="devis_list" class="content">
						<form action="" method="get" id="form_recherche_devis" class="search">
												 					<div class="fleft">
						<label for="src_date_devis">Date : </label><input name="date" id="src_date_devis" class="textfield datepicker hasDatepicker" value="" type="text">
                        </div>
                        <div class="fleft">
						<label for="src_montant">&nbsp;&nbsp;&nbsp;Montant : </label><input class="textfield number" name="montant" size="20" id="src_montant" value="" type="text"> €
                        </div>
												
	<div class="fleft">
                      
		<label for="src_reference_devis">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;N° Devis : </label>
    	<input autocomplete="off" name="ref" id="src_reference_devis" class="textfield code" value="" type="text" />
		<div class="suggestionsBox" id="suggestions_reference" style="left: 65px;">
			
				<div class="suggestionList" id="autoSuggestionsList_reference">
									&nbsp;
				</div>
			<div class="hide">
        	devis/autoCompleteRef
        	</div>
        </div>    
	</div> 							
                           
                           
                            <div class="fleft">
								
							<label for="src_etat">&nbsp;&nbsp;&nbsp;Etat : </label>
							<select name="etat" id="src_etat">
								<option value="">Tous états</option>
								<option style="background-color: rgb(227, 227, 227);" value="Brouillon">Brouillon</option>
								<option value="En attente">En attente</option>
								<option style="background-color: rgb(227, 227, 227);" value="Validé">Validé</option>
								<option value="Refusé">Refusé</option>
								<option style="background-color: rgb(227, 227, 227);" value="Dépassé">Dépassé</option>
							</select>
                            </div>

						 <a href="#" class="button submit"><span><img src="../images/magnifier.png" alt="Recherche">Rechercher</span></a>
		
				
					<span><a href="#" class="button bouton_deroulant"><span><img src="../images/advanced_search.png" alt="Recherche avancée"> Infos récapitulatives</span></a>
					</span>
                    
					
                    
                    <div class="hide" id="form_recherche_avancee">
						<div class="fleft">
						<?php // Je vais maintenant regarder ce que nous allons afficher...
						if ($cnt == '0')
						{
							echo 'Vous n\'avez aucun devis créé.';
						}
						elseif ($cnt == '1')
						{
							echo 'Vous avez un 1 devis créé dont le montant s\'élève à '.$montantTotal.' €.';
						}
						else
						{
							echo 'Vous avez un total de '.$cnt. ' devis créés pour un montant total de '.$montantTotal.' €. ';
							
							if ($cntVal == '0') // Je controle si il faut mettre au pluriel ou pas
							{ 
								echo 'Sur ces devis, aucun n\'est validé.';
							}
							elseif ($cntVal == '1') 
							{ 
								echo 'Un devis est validé pour un montant de '.$montantValide.' €.';
							}
							else
							{
								echo 'Sur ces devis, '.$cntVal. ' sont validés pour un montant de '.$montantValide.' €.';
							}
						}
						?>
						
                        </div>
                        &nbsp;
                    </div>    
                            
                    </form>   
				</div>
				
				
								<table cellspacing="0">
					<tbody><tr>
                    	<th width="50">&nbsp;</th>
						<th class="aleft" width="80">▼ Numéro</th>
						<th width="80">▼ Date</th>
						<th class="aleft" width="140">▼ Date de Validité</th>
						<th width="120">▼ Nom Client</th>
						<th width="100">▼ Montant</th>
						<th width="100">▼ Etat</th>
						<th>Actions</th>
						
					</tr>
							
			
<?php

if (empty($devis_data) && empty($rechCritere))
	{ echo '<tr><td colspan="9" class="acenter">
            Aucun devis créé
            </td></tr>';
	}
elseif (empty($devis_data) && !empty($rechCritere))
{ echo '<tr><td colspan="9" class="acenter">
            Aucun résultat pour votre recherche, essayez d\'autres critères.
            </td></tr>';
	}
else {
	$tab_devis_data_count = count($devis_data);




for ($i=0; $i<$tab_devis_data_count; $i++)
	{
		$z= $i+1; // Me permet d'avoir une numérotation qui commence à 1 et non à 0 comme le voudrait l'incrémentation du for... J'aurais pu mettre $i=1 mais vu qu'il s'agit d'une correction de bug, il est possible que ce $i=0 ait un impact trop important que pour risquer une modification... A voir dans le futur :)
		
// ********** Je rends ma date de validité lisible***********
$tmp = explode('-', $devis_data[$i]['dateVal']);
$dateValidite = $tmp[2].'/'.$tmp[1].'/'.$tmp[0];			
		
		// Attention, si l'état du devis est "Refusé" et que la recherche ne porte pas sur refusé, je ne l'affiche pas... 
		
		if ( $devis_data[$i]['etat'] != "Refusé" || $rechEtat == "Refusé" || $rechEtat == "Dépassé")
		{
		
		echo '<tr>
			<td class="acenter" id="noeud" onclick="window.location.href=\'visualiser.html?origine=dev&id='.$devis_data[$i]['id'].'\';"><input id="doc_id" type="hidden" value="'.$devis_data[$i]['id'].'"  />'.$z.'</td>
			<td class="acenter" id="test" onclick="window.location.href=\'visualiser.html?origine=dev&id='.$devis_data[$i]['id'].'\';">'.$devis_data[$i]['devNum'].'</td>
			<td class="acenter" onclick="window.location.href=\'visualiser.html?origine=dev&id='.$devis_data[$i]['id'].'\';">'.$devis_data[$i]['dateDoc'].'</td>
			<td class="acenter" onclick="window.location.href=\'visualiser.html?origine=dev&id='.$devis_data[$i]['id'].'\';">'.$dateValidite.'</td>
			<td class="acenter" onclick="window.location.href=\'visualiser.html?origine=dev&id='.$devis_data[$i]['id'].'\';">'.$_SESSION['devis_data'][$i]['nomClient'].'<div style="font-size:9px;">&nbsp;&nbsp;'.$devis_data[$i]['code_client'].'</div></td>
			<td class="acenter" onclick="window.location.href=\'visualiser.html?origine=dev&id='.$devis_data[$i]['id'].'\';">'.$devis_data[$i]['montant'].'€</td>
			
			
			<td class="vtop aleft">';
			
// Gestion des états.			

		
		switch($devis_data[$i]['etat']){
			case 'Brouillon':
				echo '&nbsp;<img src=../images/diode_orange.png alt="Brouillon" class="inline" />&nbsp;<a href="#" class="changer_etat underline">'.$devis_data[$i]['etat'].'</a>';
				break;
			case 'En attente':
				echo '&nbsp;<img src=../images/diode_orange.png alt="En attente" class="inline" />&nbsp;<a href="#" class="changer_etat underline">'.$devis_data[$i]['etat'].'</a>';
				break;
			case 'Validé':
				echo '&nbsp;<img src=../images/diode_verte.png alt="Validé" class="inline" />&nbsp;<a href="#" class="changer_etat underline">'.$devis_data[$i]['etat'].'</a>
				<br />
				<div style="font-size:9px;">&nbsp;&nbsp;'.$devis_data[$i]['date_etat'].'</div>
				';
				break;
			case 'Refusé':
				echo '&nbsp;<img src=../images/diode_rouge.png alt="Refusé" class="inline" />&nbsp;<a href="#" class="changer_etat underline">'.$devis_data[$i]['etat'].'</a>';
				break;
		}
			
			
	echo '</td>
		  <td align="right">';
	
			
	if ($devis_data[$i]['etat'] != "Validé" )
	{		
			
		echo '<a href="ajouter_un_devis.html?origine=devis&numDoc='.$i.'" title="Modifier"><img src="../images/pencil.png" alt="Modifier" class="inline"></a>';
	}
	
	echo '<a href="chantier.html?action=transit&origine=bdc&numDoc='.$i.'" title="Transformer en bon de commande" style="margin-left: 8px;"><img src="../images/go2bdc.png" alt="bdc" class="inline"></a>';
	
	if ($devis_data[$i]['etat'] != "Validé" )
	{									
										echo '<a href="suppression.html?origine=devis&numDoc='.$devis_data[$i]['id'].'"';?> onclick="return(confirm('Etes-vous sûr de vouloir supprimer cette entrée?'));"<?php echo 'title="Supprimer" style="margin-left: 5px;"><img src="../images/delete.png" alt="Supprimer" class="inline"></a>';
	}else
	{
		echo '<img src="../images/delete_blk.png" class="inline" style="margin-left: 5px;" />';
	}
										
                                       
							echo '</td>
									
									</tr>';
		} // Fin du if etat != Refusé
		
	}
}
?>			
			</tbody></table>			
	</div>
	
	
		
	<div id="devis_add" class="hide content">
			</div>	


</div>
</div>



<?php
include('./footer.php');
mysql_close();
?>
</html>
