<?php
// Attention, la date en haut de la facture est conçue pour afficher la date du jour... il faudra modifier ça lorsqu'il y aura une connexion à la base de données et/ou modification de facture pour prendre la date de CREATION DE LA FACTURE... 

// Penser à modifier le nom des tables afin de les uniformiser... en effet SOIT je fais une page d'impression distincte pour chaque module ( non conseillé vis à vis d'une multiplication des fichiers avec quasi le même code ), soit je fais un fichier de fonctions regroupant les diverses sauvegardes, soit donc j'uniformise ma base de données.

// Donc, comme conseillé par Cédric. Revérifier avant l'input dans la base que le numéro de dev/facture/bon de commande est tjrs bien le même car si 2 personnes encodent 1 nouvelle facture en même temps, le numéro ne sera pas incrémenté => 2 numéros les même...

// On sait que si $_SESSION['infos_generales']['id'] n'est pas vide, il s'agit d'une mise à jour => on fait un update et non un insert

require('function.inc.php');
$date=date('d/m/Y');


// Que faut-il afficher en haut du document ? On regarde d'où on vient et on affiche dès lors facture, bon de commande ou devis.
switch ($_SESSION['infos_generales']['origine']) {
case facture:
	$titre = 'Facture N° '.$_SESSION['numero_facture']['factNum'].' du '.$_SESSION['infos_generales']['dateDoc'];
	$libelle = "facture";
	break;
case devis:
	$titre = 'Devis N° '.$_SESSION['infos_generales']['devNum'].' du '.$_SESSION['infos_generales']['dateDoc'];
	$libelle = "devis";
	break;
case bdc:
	$titre = 'Bon de commande N° '.$_SESSION['infos_generales']['bdcNum'].' du '.$_SESSION['infos_generales']['dateDoc'];
	$libelle = "bon de commande";
	break;
}
	



?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $titre; ?></title>
<link rel="stylesheet" type="text/css" href="../css/imprime_doc.css" media="all" />
<link rel="stylesheet" type="text/css" media="print" href="../css/print.css" />
<?php
// Rechargement de mes données de facture
unset($fact_data); // Je vide ma variable
$fact_data = $_SESSION['fact_data'];
$infos_generales = $_SESSION['infos_generales'];
$fact_data = array_values($fact_data);	// Je rectifie au cas où... Ré-organisation de mes valeurs...
$taille = count($fact_data);
$ristourne_globale = $_SESSION['infos_generales']['ristourne_client'];




// On récupère les données nécessaires au traitement des taux de TVA
		$requete = 'SELECT id, tva FROM ' . $tab_tauxtva . ' ORDER BY tva ASC' ;
		$mysql_result = mysql_query($requete, $db);
$champs_tva = ' ';		
$i=0;		
		while($data = mysql_fetch_assoc($mysql_result))
							{
								
	$table_TVA[$i] = $data['tva'];
	$i++;	
								

							}

$taille_table_TVA = count($table_TVA); // Quelle taille fait donc notre table ?	
?> 

</head>
<body>
		

	
	


<div id="apercu_devis" style="border: medium none; padding: 0px;">
			
			<div style="margin-top: 10px;">
				<div class="acenter gras" style="border-bottom: 1px solid black;">
                
<?php 
echo $titre; // On affiche le nom de la facture
?> 				
                 </div>
				
				<div style="width: 250px; padding: 10px; margin: 10px; float: left;">
								
					<?php echo '<p>Par : <strong>'.$_SESSION['ent_nom'].'</strong> '.$_SESSION['ent_stat'].'</p>					
                    <p><strong>'.$_SESSION['ent_adresse'].'<br />
					'.$_SESSION['ent_cp'].' '.$_SESSION['ent_localite'].'</strong></p>';

echo '<p>Tél : '.$_SESSION['ent_tel'].'<br />
		 Fax : '.$_SESSION['ent_fax'].'<br />
		 N° d\'entreprise : '.$_SESSION['ent_tva'].'</p>';
		
		
					
					?>																				
				</div>
           
                
			
				<div style="width: 325px; margin-top:3.3cm; margin-right:1cm; float: right;">
 
<?php
// Mes infos du client
				
echo '<p style="font-size:16px">Pour : <strong>'.$_SESSION['infos_generales']['nomClient'].'</strong></p>					
<p style="font-size:14px">'.$_SESSION['infos_generales']['adresse'].'</p>					<p style="font-size:14px">'.$_SESSION['infos_generales']['code_postal'].' '.$_SESSION['infos_generales']['ville'].'</p>					
<p>'.$_SESSION['infos_generales']['pays'].'</p>										
					<p style="font-weight: bold;">N° de TVA : '.$_SESSION['infos_generales']['tva_intra'].'</p>					
<p>Code client : '.$_SESSION['infos_generales']['code_client'].'</a></p>';
?>
				</div>
				
				<hr>
			</div>
<?php // Ci dessous je vérifie bien qu'on a une info et qu'on est dans devis afin d'afficher une date de validité :)
if (isset($_SESSION['infos_generales']) && $_SESSION['infos_generales']['date_validite'] != '' && $libelle=="devis") {
	echo '<h3>Ce devis est valable jusqu\'au '.$_SESSION['infos_generales']['date_validite'].'</3>';	 
}
?>
			
			
			<div style="margin-top: 10px;">
				<table id="tab_document" cellspacing="0">
					<tbody><tr>
                    	<th class="acenter bleu" style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);" width="20">#</th>
						<th class="acenter bleu" style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);">Désignation</th>
						<th class="acenter bleu" style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);" width="25">Qté</th>
                        <th class="acenter bleu" style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);" width="50">Unité</th>
                        <th class="acenter bleu" style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);" width="50">Prix u.HT</th>
                        
						<th class="aright bleu" style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);" width="50">Remise HT</th>
						<th class="aright bleu" style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);" width="35">Ristourne HT</th>
						<th class="aright bleu" style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);" width="75">Montant HT</th>
					</tr>
<?php
// Nous allons charger les paramètres du tableau contenant les données de factures ( $fact_data ). Notre tableau à la forme $fact_data[$ligne]["valeur"]

$tab_fact_max = count($fact_data);

for ($i=0; $i<$tab_fact_max; $i++){
	
// Premièrement je calcule sur l'élément en cours son Prix HT* quantité moins la remise

	// On en profite pour calculer le total prix unitaire * quantité
	$elem_HT = $fact_data[$i]['prix']*$fact_data[$i]['qte'];

	// Pour cela, je veux savoir si il s'agit d'une remise en € ou en % 
	// Si jamais l'unite de remise est l'euro, on fait une simple 		addition sinon on converti d'abord en euros avant d'additionner en dessous...

// Je crée une valeur _tmp afin de la ré-utiliser

if ($fact_data[$i]['unite_remise']=="€")
		{
			$remise_HT_tmp = $fact_data[$i]['remise'];	
		}
	else {
			$remise_HT_tmp = $elem_HT*($fact_data[$i]['remise']/100);
		}		
		
	// Ensuite je peux effectuer le calcul... Pour ce faire j'enlève encore les X pourcents de Ristourne client ( celle qui se trouve dans les paramètres du client... La Ristourne globale donc !	
	
$prix_HT = $elem_HT-$remise_HT_tmp;  // j'enlève déjà la 1ere remise sur le produit que j'ai calculé ci-dessus...

	// Je calcule maintenant le montant la ristourne globle en €

	$ristourne_globale_calc = $elem_HT*($_SESSION['infos_generales']['ristourne_globale']/100);

	// Et je soustrait ma ristourne globale du prix...
	
	$prix_HT = $prix_HT - $ristourne_globale_calc;


// Je calcule maintenant la TVA sur ce prix HT - remise - ristourne

$tva_de_prix = $prix_HT*($_SESSION['infos_generales']['tva']/100);


// Maintenant je dois classifier les TVAs...
// Donc : Est-ce que j'ai une base à 6, 12 ou 21 ? Je vais comparer dans mon tableau des valeurs...

// Je me crée une boucle qui va regarder les divers taux proposés. Ensuite comparer les taux avec celui en cours $fact_data[$i]['tva']. Si c'est le même, on ajoute le montant à la variable adéquate.

/*
for($j=0; $j<$taille_table_TVA; $j++)
{

$tmp = $fact_data[$i]['tva']; // par simplicité de lecture pour la suite...

if ($table_TVA[$j] == $tmp)
	{
		$total_base_TVA[$tmp] = $total_base_TVA[$tmp] + $prix_HT;
		$total_TVA[$tmp] = $total_TVA[$tmp] + $tva_de_prix;
	}
}
*/


if ($_SESSION['infos_generales']['tva'] != '0')
{
	for($j=0; $j<$taille_table_TVA; $j++)
	{

		$tmp = $_SESSION['infos_generales']['tva']; // par simplicité de lecture pour la suite...

		if ($table_TVA[$j] == $tmp)
		{
			$total_base_TVA[$tmp] = $total_base_TVA[$tmp] + $prix_HT;
			$total_TVA[$tmp] = $total_TVA[$tmp] + $tva_de_prix;
		}
	}	
}


// TOUTES LES INFOS POUR LE TABLEAU TVA SONT DONC LA...

// Maintenant on s'attaque au tableau récapitulatif...

// Je calcule donc le montant hors TVA 	
	
	$montant_HT = $montant_HT + $prix_HT;
	
	
	
	

	
	
	echo '<tr id="'.$i.'"><td class="vtop">'.$i.'</td>
	 						<td class="aleft"><div>'.$fact_data[$i]['designation'].'</div>'.$fact_data[$i]['detail'].'</td>
							<td class="vtop cell_qte aright">'.$fact_data[$i]['qte'].'</td>
							<td class="vtop cell_qte aright">'.$fact_data[$i]['unite'].'</td>
							<td class="vtop cell_prix_ht aright">'.$fact_data[$i]['prix'].' &euro;</td>
							
							<td class="vtop cell_remise aright">'.$remise_HT_tmp.' €';
// si l'unité de la remise est le % alors on affiche :
	if ($fact_data[$i]['unite_remise'] == "%")
		{
			echo '<p style="font-size:9px">'.$fact_data[$i]['remise'].' '.$fact_data[$i]['unite_remise'].'</p></td>';
		}
		
// Si il y a une ristourne globale on l'affiche
echo '<td class="vtop cell_remise aright">';

if (isset($_SESSION['infos_generales']['ristourne_globale']) )
	{
		echo $ristourne_globale_calc.' €<p style="font-size:9px">'.$_SESSION['infos_generales']['ristourne_globale'].'% </p>';
	}
echo '</td>
							
							
							<td class="vtop cell_total aright">'.$prix_HT.' &euro;
							<p style="font-size:12px">TVA : '.$fact_data[$i]['tva'].' %</p>					
							</td>
						</tr>';
}

// Et je continue ici le calcul sur le tableau récapitulatif
	

// Maintenant place à la remise globale sur le montant HT - remise HT en pourcents

	


// Calcul en direct du montant HT
$total_HT = $montant_HT; // Il s'agit d'une réminiscence d'ancien codes... Je garde ces 2 variables dans le doute... A nettoyer plus tard ! 


// TOTAL TTC !!!!!!!!!!!!!!!!!!!!!!
	// On calcule toute la TVA accumulée plus haut dans le tableau

for ($i=0;$i<$taille_table_TVA;$i++)
	{
$tmp = $table_TVA[$i];		
		
$TVA_a_payer = $TVA_a_payer + $total_TVA[$tmp]; 
	}


?> 
			
				</tbody></table>

<div id="blocTVA">  <!-- Je crée ici un tableau de TVA --> 
<?php               
// On va vérifier que la case co-contractants n'était pas cochée sinon on affiche à la place du tableau TVA la mention légale
if ($_SESSION['infos_generales']['tva'] == "0")
	{ 
		echo '<br /><br /><h3 class="cocontractants">Autoliquidation</h3>';
		$TVA_a_payer = '0'; // La TVA a payer devient 0€
	}
else // Donc si on est pas en cocontractants alors on calcule le total net + TVA et... C'est bon
	{
  ?>              

	<table class="tableau_tva margin-bottom margin-top" cellspacing="0"> 
    	<tr>
        <td style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);">Base TVA</td>
        	<td style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);">
            Taux TVA
            </td>
            <td style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);">
            TVA calculée
            </td>
        <tr>

<?php


for($i=0; $i<$taille_table_TVA; $i++){
echo '<tr>';

if ($table_TVA[$i] != 0)
	{
$tmp = $table_TVA[$i];
$total_TVA[$tmp] = round($total_TVA[$tmp], 2);
	echo '<td>'.$total_base_TVA[$tmp].' €</td>';
	echo '<td>'.$tmp.' %</td>';	
	// On va maintenant ajouter le total TVA inhérent au taux en cours
	echo '<td>'.$total_TVA[$tmp].' €</td>';
	

	}
echo '</tr>';
}
?>
</table>
<?php
} // fin du if cocontractant
?>

</div> 
  
 
<?php
// Un dernier petit calcul avant le verdict final
// On peut ajouter au total HT la TVA	
	
$total_TTC= $total_HT+$TVA_a_payer;               
?>				
								
				<div id="blocTotaux">				
        <table class="tableau_totaux margin-bottom margin-top" cellspacing="0">
					<tbody>
					
								
					<tr><td>Total HT : <br></td><td><span id="totalHT">
<?php


echo $total_HT;?>&nbsp;€</span><br></td></tr>

<tr>
                    	<td>TVA : </td>
                    	<td id="totalTVA"> <?php 
						$TVA_a_payer = round($TVA_a_payer,2); // Arrondi
						echo $TVA_a_payer; ?>&nbsp;€</span>


</td></tr>


							
					<tr><td>Total TTC :</td><td id="totalTTC"><?php 
					$total_TTC = round($total_TTC,2);
					echo $total_TTC; ?>&nbsp;€</td></tr>
                    
          
          
               
                    
                    
                    
<tr>
<td>Frais de port :</td>
<td><span id="totalFdp"><?php echo $_SESSION['infos_generales']['frais_de_port'];?> €</span>
						</td>
					</tr>                    
                    
                    

<?php // calcul Net à payer
$total_net = $total_TTC + $infos_generales['frais_de_port'];

// Ensuite je regarde si il y avait un acompte, si oui je modifie la tableau pour qu'il calcule un sous total puis ensuite un Reste à payer

if (isset($infos_generales['acompte']) && $infos_generales['acompte'] != '0' && $infos_generales['acompte'] != '') {
	echo '
	<tr><th style="background-color: rgb(135, 206, 250); color: rgb(0, 0, 0);">Net TTC :</th><th id="netTTC" style="background-color: rgb(135, 206, 250); color: rgb(0, 0, 0);">'.$total_net.' €</th></tr>
	
	<tr>
		<td>Acompte</td>
		<td>- '.$infos_generales['acompte'].' €</td>
	</tr>';
	
// Calcul du reste à payer...	

$total_net = $total_net-$infos_generales['acompte'];
$valeur_a_afficher = "Restant à payer TTC :";
}
else
	{
		$valeur_a_afficher = "Net à payer TTC :";
	}
?>					
	
						
                    
					<tr><th style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);"><?php echo $valeur_a_afficher; ?></th><th id="netTTC" style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);"><?php echo $total_net; ?>&nbsp;€</th></tr>
				</tbody></table>
			</div>
				
						
			
			<hr>

			
			<div class="autres_infos" style="padding: 10px; margin-top: 10px;">
            <!-- l'argument de style "page-break-after" provoque un saut de page afin de pouvoir imprimer les conditions générales au verso ;) -->
				
<?php
// Doit on afficher une note ?
if ($infos_generales['notes'] != "")
	{
		$notes = nl2br($infos_generales['notes']);
		echo '<p><strong>Note : </strong>'.$notes.'</p><br />';
	}

if ($infos_generales['fact_date'] != '')
{
	echo '<strong>limite de paiement : '.$infos_generales['fact_date'].'</strong><br />';
}
elseif ($infos_generales['fact_paye'] != '')
{
	echo '<strong>Facture payée le : '.$infos_generales['fact_paye'].'</strong><br />';
}
						
?>										
					<strong style="text-decoration:underline">Conditions de règlement :</strong> <?php echo $infos_generales['mode_reglement']; ?><br />
<?php
if (isset($_SESSION['infos_generales']) && $_SESSION['infos_generales']['delai_reglement'] != '') {
	echo 'Facture à payer à j+'.$_SESSION['infos_generales']['delai_reglement'];	 
}					
?>
					
			</div>
            				
<div align="center" style="margin-top:50px">	
<a href="?action=rec" class="button margin-right" id="button" rel="enreg"><span><img src="../images/pencil.png" alt="enreg">Enregistrer</span></a>
<a href="?action=rec_print" class="button margin-right" id="button" rel="imprime"><span><img src="../images/printer.png" alt="imprime"> Enregistrer et Imprimer</span></a>
</div>

<?php
if (file_exists('./images/condgen/'.$_SESSION['ent_affil'].'_condgen.jpg'))
	{
		echo '
		<div class="cond_gen" style="page-break-before:always">
		<img src="../images/condgen/'.$_SESSION['ent_affil'].'_condgen.jpg" style="height : '.$_SESSION['condGen']['hauteur'].'cm ; width : '.$_SESSION['condGen']['largeur'].'cm; margin-left:'.$_SESSION['condGen']['marGauche'].'cm; margin-top:'.$_SESSION['condGen']['marHaut'].'cm;" />
		</div>';
	}


$action = $_GET['action'];
if ($action != '')
	{
		if ($action == 'rec' )	// Donc si on a appuyé sur le bouton rec ou rec_print alors...
			{
				// Alors je dois savoir si il y avait un "héritage" en gros si on met à jour avec upload ou si j'enregistre un nouvel élément
				if ($_SESSION['infos_generales']['id'] != '') // Si il est différent de rien alors il s'agit d'une mise à jour...
					{
						Majdata($total_net);
					}
				else
					{
						Recdata($total_net, 'Brouillon');
					}
			}


		if ($action == "rec_print")
			{
				
				Recdata($total_net, 'En attente');
				
				echo '<script language="javascript" type="application/javascript">
						function noBack(){window.history.forward()} 
						noBack(); 
						window.onload=noBack; 
						window.onpageshow=function(evt){if(evt.persisted)noBack()} 
						window.onunload=function(){void(0)} 
						javascript:window.print();
						</script>';
			}
	
	// Je vide mes variables de session avant de partir
				unset($_SESSION['fact_data']);
				unset($_SESSION['infos_generales']);
				unset($_SESSION['devis_data']);
				unset($_SESSION['bonDeCom_data']);
				unset($_SESSION['facture_data']);
				
	
	
	// Et ensuite on redirige vers la page de garde

				echo '<script language="javascript">
				<!-- code for my StatScript here -->
				window.location="../accueil/index.html";
				</script>';

	}
?>
</div>
</div>
</body>
</html>
