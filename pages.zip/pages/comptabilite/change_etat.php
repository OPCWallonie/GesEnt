<?php
$origine = $_GET['origine'];
$etat =  $_GET['etat'];
$doc_id = $_GET['doc_id'];
$action = $_GET['action']; // Afin de savoir si on doit sauver ou pas :)


if ($etat == "Valide") {
	$etat = "Validé";
} 
elseif ($etat == "Refuse") {
	$etat = "Refusé";
}
elseif ($etat == "Payee") {
	$etat = "Payée";
}
elseif ($etat == "Impayee") {
	$etat = "Impayée";
}


function Sauvegarde($origine, $etat, $doc_id){
	
	
	
	$sql = "UPDATE gf_".$origine." 
	SET 
		etat='".$etat."'		
	WHERE id = '".$doc_id."'";
	
	mysql_query('set names utf8');
	mysql_query($sql) or die('Erreur SQL !'.$sql.'<br>'.mysql_error());					
	mysql_close();	
	$etat='quit';
	echo'
	<script>
	self.close();
	</script>
	';	
}

function SauvegardeDate($origine, $etat, $doc_id, $dateVal){
	
	
	
	$sql = "UPDATE gf_".$origine." 
	SET 
		etat='".$etat."',
		date_etat='".$dateVal."'		
	WHERE id = '".$doc_id."'";
	
	mysql_query('set names utf8');
	mysql_query($sql) or die('Erreur SQL !'.$sql.'<br>'.mysql_error());					
	mysql_close();	
	$etat='quit';
	echo'
	<script>
	self.close();
	</script>
	';	
}






?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Untitled Document</title>



<link type="text/css" href="../css/jquery.datepick.css" rel="stylesheet" />
	
	





<style type="text/css">
* { margin: 0px; padding: 0px; }
body { color: rgb(0, 0, 0); font: 0.8em/1.3em "Trebuchet MS",Verdana,"Lucida Grande",Tahoma,Helvetica,Sans-Serif; background: none repeat scroll 0% 0% rgb(255, 255, 255); }
h1 { margin-bottom: 20px; padding: 5px 25px 5px 5px; font-size: 1.6em; background: none repeat scroll 0% 0% rgb(51, 51, 51); text-align: center; color: rgb(255, 255, 255); line-height: 1.2em; }

div#pop-content { padding: 10px; }
.margin-bottom { margin-bottom: 10px; }


a.underline { text-decoration: underline; }
a.underline:hover { text-decoration: none; }
.aleft { text-align: left; }
.acenter { text-align: center; }
.aright { text-align: right; }
.gras { font-weight: bold; }
.padding5 { padding: 5px; }
.gris01 { background: none repeat scroll 0% 0% rgb(230, 230, 230); }
a.button { display: inline-block; height: 30px; background: url('../images/bouton-right.png') no-repeat scroll 100% 0px transparent; line-height: 30px; font-size: 14px; font-weight: normal; }
a.button span { display: block; height: 30px; margin-right: 3px; padding: 0px 3px 0px 6px; background: url('../images/bouton-left.png') no-repeat scroll 0px 0px transparent; }
a.button:hover, a.button:focus { background-position: 100% -30px; text-decoration: none; cursor: pointer; }
a.button:hover span { background-position: 0px -30px; }
a.button span img { float: left; margin: 8px 5px 7px 0px; display: inline; }

.ui-helper-hidden-accessible { position: absolute; left: -1e+8px; }
.ui-helper-clearfix:after { content: "."; display: block; height: 0px; clear: both; visibility: hidden; }
.ui-helper-clearfix { display: inline-block; }
.ui-helper-clearfix { display: block; }
.ui-widget { font-family: Verdana,Arial,sans-serif; font-size: 1.1em; }
.ui-widget-content { border: 1px solid rgb(170, 170, 170); background: url('../images/ui-bg_flat_75_ffffff_40x100.png') repeat-x scroll 50% 50% rgb(255, 255, 255); color: rgb(34, 34, 34); }
.ui-widget :active { outline: medium none; }
.ui-corner-all { border-radius: 4px 4px 4px 4px; }
button.ui-button::-moz-focus-inner { border: 0px none; padding: 0px; }
button_bis.ui-button::-moz-focus-inner { border: 0px none; padding: 0px; }

.ui-datepicker { width: 17em; padding: 0.2em 0.2em 0px; z-index: 2; display: none; }

form div {
    text-align: center; /* ie8 ne veut pas d'input en display block */
}
 
.submit {
    display: block;
    display: inline-block;
    margin: 4px auto 0; /* centrer le submit pour navigateur autre que ie8 */
}

.texteInfo {
	font-size:10px;
}

</style>










<style type="text/css">
#container_frame {
	width:220px;
	height:75px;
	margin-top:auto;
	margin-bottom:auto;
	margin-left:auto;
	margin-right:auto;
	text-align:center;
	
	
	
}
</style>
</head>
<body>
<h1>Action requise</h1>
<?php


// Si on valide, on ne peut plus modifier donc rajouter des champs dans la base... peut-on modifier ou pas... ( ou alors un test sur la BD, si il y a déjà un champs existant pour la date, on ne sauvegarde pas... c'est possible aussi ;)

if ($action==Valide)
{
	
	
	$date = $_POST['dateVal'];
	if(!empty($date))
	{
		SauvegardeDate($origine, $etat, $doc_id, $date);
	
		echo'
		<script language="javascript">
		parent.Shadowbox.close();
		</script>';
	}
	else {
		echo'
		<script language="javascript">
			alert("Veuillez insérer une date");
		</script>';	
	}
	
	
}

// si l'état == quit, alors ferme la fenetre








// Au cas où, on défini ceci... Je pourrais le faire après le test général ( est ce qu'il faut afficher ma boite ? Si oui c'est forcément un payement ou une acceptation... Mais bon... Le code me semble + lisible comme ça...
if ($etat == "Validé")
{
	$label = "d'acceptation";
} 
elseif ($etat == "Payée")
{
	$label = "de payement";	
}

// Et maintenant le test général... Affiche-t-on la date ou bien sauvegarde-t'on directement ?

if ($etat == "Validé" || $etat == "Payée")
{
echo'	
<div id="container_frame" >
<form id="formulaire" action="?action=Valide&doc_id='.$doc_id.'&origine='.$origine.'&etat='.$etat.'" method="post">
<label for="dateVal">Date '.$label.' :</label>
<input id="dateVal" name="dateVal" type="text" size="10" value="'.$_POST['dateVal'].'"/>
<input id="doc_id" type="hidden" value = "'.$doc_id.'" />
<input id="origine" type="hidden" value = "'.$origine.'" />
<input id="etat" type="hidden" value = "'.$etat.'" />
<br />
<br />
<br />
<div>
<input type="submit" class="submit" title="Valider" id="submit" align="middle" />
</div>
<br />
<br />
<br />
<div class="texteInfo">
Cette date indique à quel moment votre devis/bon de commande/facture à été accepté.
</div>
</form>
</div>';

}
else
{
	Sauvegarde($origine, $etat, $doc_id);
}

?>




<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript" src="../scripts/inherited/jquery.datepick.js"></script>
<script type="text/javascript" src="../scripts/inherited/jquery.datepick-fr.js"></script>


<script>
  $(function() {
    $( "#dateVal" ).datepick();
  });
  </script>


</body>
</html>

