<?php
// Supprimer un devis
$origine = $_GET['origine'];
$numDoc = $_GET['numDoc'];

$sql = 'DELETE FROM gf_'.$origine.' WHERE id="'.$numDoc.'"';
mysql_query($sql) or die('Erreur SQL !<br>'.$sql.'<br>'.mysql_error()); 

// Et on redirige
if ($origine=="bdc")
{
	$origine = "bons_de_commandes"; // Je rectifie pour la redirection ci-dessous afin que ça colle au nom du fichier...
}

echo '<http><head><meta http-equiv="Refresh" content="0;url=../comptabilite/'.$origine.'.html"></head><body></body></html>';
exit;
?>