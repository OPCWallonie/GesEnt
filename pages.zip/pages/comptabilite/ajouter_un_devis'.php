<?php
// Session créée ? Sinon, en créer une nouvelle
if($PHPSESSID) session_start($PHPSESSID);
else session_start();

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<?php

// Attention, lorsque je mettrai en place le module de mise à jour de devis, bien prendre soin de remettre à zéro l'actio si il ne s'agit PAS d'une mise à jour... Car si on encode 2 factures/devis/bons de commande d'affilée, nous aurons un gros bug où il voudra mettre à jour lors de l'enregistrement et non pas créer une nouvelle facture/devis/bon de commande.



// On va d'abord regarder si il ne s'agit pas d'une mise à jour héritée de la page des devis... sinon c'est différent.

$numDoc = $_GET['numDoc'];
if ($numDoc != '') {
	// On restaure les données => en gros
	$_SESSION['infos_generales'] = $_SESSION['devis_data'][$numDoc];
	$infos_generales = $_SESSION['infos_generales'];
	// On remet les données de facturations
	$_SESSION['fact_data'] = unserialize($_SESSION['devis_data'][$numDoc]['dev_serialize']);
	$fact_data = $_SESSION['fact_data'];
	
}
else
{




	// Si ma variable de session contenant les données de la facture existe, je la recharge et dé-sérialise dans un tableau fact_data
	if (isset($_SESSION['fact_data']))
	{
		$fact_data = $_SESSION['fact_data'];
		$taille = count($fact_data);
	}
	else 
	{
		$taille=0;
	}

	$action = $_GET['action'];



	if ($action == 'update_infos_ligne')
	{
	$taille = $_GET['id']; // Entourloupe pour utiliser la mise en place du tableau ci-dessous ;)
	}
	if ($action == 'ajouter_ligne' OR $action == 'update_infos_ligne')
	{
	// Nous allons regarder si la valeur du post précédent est égal au poste actuel... Si c'est le cas, on stocke les données dans la variable de session

		if ($fact_data[$taille-1]['designation'] != $_POST['designation'] && $fact_data[$taille-1]['prix'] != $_POST['prix']) // On s'évite des doublons
		{
			$fact_data[$taille] = array( 	designation => $_POST['designation'],
											detail => $_POST['detail'],
											prix => $_POST['prix'],
											remise => $_POST['remise'],
											unite_remise => $_POST['unite_remise'],
											qte => $_POST['qte'],
											tva => $_POST['tva'],
											montant => $_POST['montant']);
			$_SESSION['fact_data'] = $fact_data;
			unset($designation);
			unset($detail);		
			unset($prix);
			unset($remise);
			unset($unite_remise);
			unset($qte);
			unset($tva);
			unset($montant);

		}





		// On place les constantes de la facture dans une variable de session... De cette manière elles sont sauvegardées et accessibles.


	

		$pour_variable_session = array(	origine => 'devis',
										frais_de_port => $_POST['frais_de_port'],
										nomClient => $_POST['nomClient'],
										adresse => $_POST['adresse'],
										code_postal => $_POST['code_postal'],
										ville => $_POST['ville'],
										pays => $_POST['pays'],
										tva_intra => $_POST['tva_intra'],
										code_client => $_POST['code_client'],
										mail_client => $_POST['mail_client'],
										mode_reglement => $_POST['mode_reglement'],
										etat_payement => $_POST['etat_payement'],
										fact_paye => $_POST['fact_paye'],
										fact_date => $_POST['fact_date'],
										ristourne_globale => $_POST['ristourne_globale'],
										ristourne_client => $ristourne_globale,
										notes => $_POST['notes'],
										date_validite => $_POST['date_validite'],
										cocontractants => $_POST['cocontractants'],
										delai_reglement => $_POST['delai_reglement'],
										acompte => $_POST['acompte']);

		$_SESSION['infos_generales'] = $pour_variable_session;
		unset($frais_de_port);
	}

	// Sous-if de redirection... En effet maintenant que les données sont enregistrées dans les variables de sessions, on peut dès lors vérifier que l'utilisateur n'a pas cliqué sur le bouton "valider"... Si tel est le cas, on le re-dirige vers notre page imprime_doc.php
}
	
if (isset($_POST['imprime_doc']))
{
	echo '<meta http-equiv="Refresh" content="0;url=../comptabilite/imprime_doc.html">';
	exit;
}
elseif ($action == 'supp_ligne')
{	 
	$id=$_GET['id']; // Quel ID a supprimer est référencé dans l'URL
	unset($fact_data[$id]); // On supprime le contenu de la ligne
	array_splice($fact_data, $id, 0); // On supprime de la mémoire la ligne
	$_SESSION['fact_data'] = $fact_data; // On enregistre les modifs dans la variable de session
}

if ($action == 'modif_ligne')
{
	// On va d'abord lire l'ID de la ligne à modifier
	$id = $_GET['id'];
	$id_ligne = $id; // Certes je pense que ça ne sert à rien MAIS à vérifier plus tard... utilisé dans le div id="form_ajout_ligne" et surtout à la définition de notre devis_form afin de pouvoir appliquer les modifs plus tard
		
		
	// Après il nous faut lire les données à ré-injecter dans le div "form_ajout_ligne" et les attribuer à des variable que nous allons définir
	$designation = $fact_data[$id]['designation'];
	$detail = $fact_data[$id]['detail'];
	$prix = $fact_data[$id]['prix'];
	$remise = $fact_data[$id]['remise'];
	$unite_remise = $fact_data[$id]['unite_remise'];
	$qte = $fact_data[$id]['qte'];
	$tva = $fact_data[$id]['tva'];
	$montant = $fact_data[$id]['montant'];
}

// Je charge les autres données qui sont stockées dans ma variable de session...
$infos_generales = $_SESSION['infos_generales'];	

?>



<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>Gestion des devis</title>
<meta name="keywords" content="" lang="fr">
<meta name="description" content="">

<meta http-equiv="Content-Language" content="fr">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<!--[if IE]><script language="javascript" type="text/javascript" src="http://www.wuro.fr/static/js/excanvas.js"></script><![endif]-->	

<link rel="stylesheet" type="text/css" href="../css/ajouter_un_devis.css" media="all">
<script language="JavaScript" type="text/javascript" SRC="../scripts/div.js"></script>


<script language="JavaScript" type="text/JavaScript">

function afficher()
{
  var a = document.getElementById("fact_payee" );
  var m = document.getElementById("fact_a_payer" );
    a.style.display = "block";
    m.style.display = "none";
}
 
function masquer()  
{  
  var a = document.getElementById("fact_payee" );  
  var m = document.getElementById("fact_a_payer" );  
 a.style.display = "none";  
 m.style.display = "block";  
}

function initial()  
{  
  var a = document.getElementById("fact_payee" );  
  var m = document.getElementById("fact_a_payer" );  
 a.style.display = "block";  
 m.style.display = "none";  
}



</script>


</head>

<?php 
// J'active par défaut si on affiche fact_paye ou fact_a_payer
if ($infos_generales['etat_payement'] == "1")
	{ echo '<body onLoad="javascript:afficher();">'; }
elseif ($infos_generales['etat_payement'] == "2")
	{ echo '<body onLoad="javascript:masquer();">'; }
else { echo '<body onLoad="javascript:initial();">'; }

include ("./menu.php");

?>

<div id="contenant">
		<span class="hide" id="type_doc">devis</span>



<div class="box">
	<h2>Gestion des devis</h2>
		
			
	
	<!--###############################################################
	############################# MENU ################################
	###############################################################-->
   <ul id="menu">        <li>
			<a href="../comptabilite/devis.html" rel="devis_list"><img src="../images/order-history64.png" alt="Liste des devis"> <span>Liste des devis</span></a>
        </li>
			
			<li>
				<a href="" rel="devis_add" class="active"><img src="../images/ordering64.png" alt="Créer un nouveau devis"> <span>Ajouter un devis</span></a>
			</li>
		</ul>   
    
    

	
	
	
		
	<div style="display: block;" id="devis_add" class=" content">
		
<h2 id="numero_document">Devis n° <input autocomplete="off" name="devis_num" class="textfield" id="devis_num" value="" type="text" maxlength="15" /></h2><!-- <span class="small">(<a href="devis/numerotation" rel="shadowbox;width=500;height=350">changer la numérotation</a>)</span>-->
		

		<div style="display: block;" id="facture_add" class=" content">

<?php



// Je décide ce qui se passe si on clique sur modifier ou sur ajouter... vu que action=modif_ligne si on veut modifier, je modifie l'entête du formulaire afin qu'il envoit vers la fonction update de données et non pas insert... 

if ($action == "modif_ligne")
{
	echo '<form id="devis_form" method="post" enctype="multipart/form-data" action="?action=update_infos_ligne&id='.$id_ligne.'" >';
}
else
{
	echo '<form id="devis_form" method="post" enctype="multipart/form-data" action="?action=ajouter_ligne" >';
}


?>


			<input name="documentId" id="documentId" value="1352" type="hidden">
			<input name="action" value="ajout" type="hidden">
			<input name="type_document" id="type_document" value="devis" type="hidden">
			<p class="toggle open">
				<a href="javascript:visibilite('client_infos');" class="options_devis">Client</a>
			</p>
			
<div id="client_infos" style="display:block">
				<fieldset id="choix_client">		
					<p class="gris01">
						<span class="toolTip" title="Renseignez dans ce champ le nom ou la société de votre client <br />
Ce nom apparaîtra dans l'entête du devis">&nbsp;</span>
						<label for="inputString">Société ou  nom :</label>
						
						<input autocomplete="off" name="nomClient" class="textfield" id="inputString" value="<?php if (isset($infos_generales)) echo $infos_generales['nomClient']; ?>" type="text"placeholder="Société" /> 					
						
					</p>
						<div class="suggestionsBox" id="suggestions" style="left: 195px;">
							<img src="../images/uparrow.png" alt="upArrow">
							<div class="suggestionList" id="autoSuggestionsList">
								&nbsp;
							</div>
							<div class="hide">contacts/autoCompleteSociete</div>
						</div>
					<p>
						<span class="toolTip" title="L'adresse de votre client apparaîtra dans l'entête du devis">&nbsp;</span>
						<label>Adresse : </label>
						<textarea name="adresse" id="adresse" cols="40" rows="2"><?php if (isset($infos_generales)) echo $infos_generales['adresse']; ?></textarea>
					</p>
                    
                   
                    
                    
					<p class="gris01">
						<span class="toolTip" title="Le code postal apparaîtra dans l'entête du devis">&nbsp;</span>
						<label>Code postal : </label>

						<input autocomplete="off" name="code_postal" class="textfield" id="codePostal" placeholder="Code Postal" type="text" value="<?php if (isset($infos_generales)) echo $infos_generales['code_postal']; ?>" /> 
                        
						
					</p>
						<div class="suggestionsBox" id="suggestions_villes" style="left: 195px; top: 145px;">
							<img src="../images/uparrow.png" alt="upArrow">
							<div class="suggestionList" id="autoSuggestionsList_villes">
								&nbsp;
							</div>
						</div>	
						<input name="idcontact" id="id_autoComplete" type="hidden">
					<p>	
						<span class="toolTip" title="La ville apparaîtra dans l'entête du devis">&nbsp;</span>
						<label>Ville : </label>
                        <input name="ville" class="textfield" id="ville" placeholder="Ville" type="text" value="<?php if (isset($infos_generales)) echo $infos_generales['ville']; ?>" />
					</p>
					<p class="gris01">
						<span class="toolTip" title="Le pays apparaîtra dans l'entête du devis">&nbsp;</span>
			      <label>Pays : </label>
                  
                  <input name="pays" class="textfield" id="pays" placeholder="Pays" type="text" value="<?php if (isset($infos_generales)) echo $infos_generales['pays']; ?>" />
                  
					</p>
					<p>
						<span class="toolTip" title="Si l'entreprise à facturer possède un numéro de tva intracommunautaire spécifiez-le dans ce champ<br />
Celui-ci apparaitra dans l'entête de la facture. Le numéro de TVA est composé du préfixe du pays suivi d'au maximum 12 chiffres ou caractères alphanumériques">&nbsp;</span>
						<label for="tva_intra">N° TVA intra :</label>
						<input name="tva_intra" class="textfield" id="tva_intra" placeholder="TVA" type="text" value="<?php if (isset($infos_generales)) echo $infos_generales['tva_intra']; ?>" />
					</p>
					<p class="gris01">
						<span class="toolTip" title="Spécifiez le code client qui vous permettra de retrouver le devis lors d'une recherche par code client">&nbsp;</span>
						<label>Code compta/client : </label><input name="code_client" id="code_client" class="textfield" value="<?php if (isset($infos_generales)) echo $infos_generales['code_client']; ?>" type="text" placeholder="cl00001">
					</p>
               
						
						<div class="suggestionsBox" id="suggestions_achat_code_client" style="left: 195px; top: 290px;">
							<img src="../images/uparrow.png" alt="upArrow">
							<div class="suggestionList" id="autoSuggestionsList_achat_code_client">&nbsp;</div>
							<div class="hide">contacts/autoCompleteCodeClient</div>
						</div>
						
					<p>
						<span class="toolTip" title="Renseignez l'adresse e-mail du client qui apparaîtra sur le devis et vous permettra si vous le souhaitez d'envoyer automatiquement le devis par e-mail">&nbsp;</span>
						<label>E-mail : </label><input name="mail_client" id="mail_client" class="textfield" placeholder="e-mail" type="text" value="<?php if (isset($infos_generales)) echo $infos_generales['mail_client']; ?>" />
					</p>
					<!--
					<p>
						<label>Envoi mail : </label><input type="checkbox" name="envoi_mail"  />
					</p>
					-->
					
				</fieldset>
			</div>
			
			
			<p class="toggle">
				<a href="javascript:visibilite('facturation_infos');" class="options_devis">Facturation</a>
			</p>
			<div id="facturation_infos" style="display:none">		
				<fieldset>
					
					<div id="ajouter_ligne">
						<p class="gris01">
							<span class="toolTip" title="Indiquez le délai de règlement en jours">&nbsp;</span>
							<label for="delai_reglement">Réglement :</label>
							à&nbsp;j + <input name="delai_reglement" id="delai_reglement" style="width: 40px;" class="textfield" value="<?php if (isset($infos_generales)){ echo $infos_generales['delai_reglement'];}else echo "30" ?>" type="text">
						</p>
						
						<p>
							<span class="toolTip" title="Choisissez un mode de paiement">&nbsp;</span>
							<label for="mode_reglement">Mode de réglement : </label> 
							<?php
// On récupère les données nécessaires à la suite du traitement des moyens de payements
	

		
?>   

 
							<select name="mode_reglement" id="mode_reglement">
								
<?php
	for ($i=0; $i < count($_SESSION['mode_payement']); $i++)
	
		{
// Si la variable infos_generales existe... Autrement dit si on a déjà donné des infos, on sait qu'on va tomber sur la valeur enregistrée en parcourant le tableau => est-ce que infos_generales est = à nom, alors data default devient 1

if (isset($infos_generales)) {
	$_SESSION['mode_payement'][$i]['defaut'] = '0';
	
	if ($infos_generales['mode_reglement'] == $_SESSION['mode_payement'][$i]['nom']) 
	{
		$_SESSION['mode_payement'][$i]['defaut'] = '1';
	}
}

echo '<option value="'.$_SESSION['mode_payement'][$i]['nom'].'" ';
	
if ($_SESSION['mode_payement'][$i]['defaut'] == '1' ) { echo 'selected="selected" '; }						
							
echo '>'.$_SESSION['mode_payement'][$i]['nom'].'</option>';
							
							}
?>
							
							
							</select>
						</p>
						
						<!--
						<p class="gris01">
							<label for="accompte_montant">Accompte : </label>
							<input type="text" name="accompte_montant" class="textfield" id="accompte_montant" style="width:100px;" value="0" />
							<select name="accompte_type">
								<option value="pourcent" >%</option>
								<option value="valeur" >€</option>
							</select>
						</p>
						-->
							<input name="accompte_montant" class="textfield" id="accompte_montant" style="width: 100px;" value="0" type="hidden"><input name="accompte_type" value="pourcent" type="hidden">
							
						<p class="gris01">
							<span class="toolTip" title="Les frais de port HT associés au devis">&nbsp;</span>
							<label for="frais_de_port">Frais de port HT : </label>
							<input name="frais_de_port" class="textfield" id="frais_de_port" style="width: 80px;" value="<?php if (isset($infos_generales)) echo $infos_generales['frais_de_port']; ?>" placeholder="00.00" type="text">&nbsp;€
						</p>
						
                        
						<!--
						<p>
							<label for="tva_globale">Tva globale : </label>
							<select name="tva_globale" id="tva_globale">
								<option value="0.0">0.0%</option><option value="5.5">5.5%</option><option value="19.6">19.6%</option><option value="21.0">21.0%</option>				
							</select>
						</p>
						
						-->
						<input name="tva_globale" value="0" type="hidden">
						
						
                        
                        
                        
                        
                        <p>
							<span class="toolTip" title="Montant de la remise globale HT en pourcentage.">&nbsp;</span>
							<label for="ristourne_globale">Remise globale HT : </label>
							<input type="text" name="ristourne_globale" id="ristourne_globale" value="<?php if (isset($infos_generales)){ echo $infos_generales['ristourne_globale'];}else echo "0" ?>" size="2" /> %
						</p>
                        
                        <p>
							<span class="toolTip" title="Acompte payé à déduire du montant total de la facture">&nbsp;</span>
							<label for="acompte">Acompte : </label>
							<input name="acompte" class="textfield" id="acompte" style="width: 80px;" value="<?php if (isset($infos_generales)) echo $infos_generales['acompte']; ?>" placeholder="00.00" type="text">&nbsp;€
                            
						</p>	
                        
                        
 <p>
            	<span class="toolTip" title="Dans le cas d'une TVA entre cocontractants, il n'est plus obligatoire depuis le 1er Janvier 2013 de référer à l'article de loi sur le report de perception. La nouvelle mention légale &quot;autoliquidation&quot; apparaîtra sur votre facture.">&nbsp;</span>
                <label for="cocontractants">TVA cocontractants : </label>
<input type="checkbox" name="cocontractants" id="cocontractants" class="textfield" value="oui" <?php if ($infos_generales['cocontractants'] == 'oui'){echo 'checked="checked"';}?> />
            </p>                       
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        				
					</div>
				</fieldset>
			</div>

		
<p>
							<span class="toolTip" title="Date jusqu'à laquelle le devis est valable. Format : Jour/Mois/Année ( JJ/MM/AAAA )">&nbsp;</span>
							<label for="date_validite">Date validité : </label>
							<input class="datepicker textfield hasDatepicker" name="date_validite" id="date_validite"  value="<?php if (isset($infos_generales)) echo $infos_generales['date_validite']; ?>" type="text" placeholder="JJ/MM/AAAA">
						</p>	
        	
	


<div id="form_ajout_ligne" class="gris01 gras padding5">
				
				<input name="id_ligne" id="id_ligne" value="<?php echo $id_ligne; ?>" type="hidden">
				<input name="type_taxe" id="type_taxe" value="ht" type="hidden">
				<input name="ht_ttc_remise" id="ht_ttc_remise" value="ht" type="hidden">
				
				<div class="ligne_designation fleft">
					Désignation : <input value="<?php echo $designation; ?>" autocomplete="off" name="designation" id="designation" class="textfield" style="width: 85%;" type="text" placeholder="Produit/Service facturé" />
					
				
						<div class="suggestionsBox" id="suggestions_designation" style="left: 0px;">
							<img src="../images/uparrow.png" alt="upArrow">
							<div class="suggestionList" id="autoSuggestionsList_designation">
								&nbsp;
							</div>
							<div class="hide">devis/autoCompleteProduit</div>
						</div>	
						<input name="idesignation" id="id_autoCompleteDesignation" type="hidden">
					
					
				</div>
				
				
				<div class="ligne_prix_ht fleft acenter">
					Prix unitaire HT<br>
					<input class="textfield aright" name="prix" id="prix" value="<?php echo $prix; ?>" type="text" placeholder="00.00" />&nbsp;€
				</div>

				
				<div class="ligne_remise_ht fleft acenter">
					Remise HT<br>
					<input class="textfield aright" value="<?php echo $remise; ?>" id="remise" name="remise" type="text" placeholder="00.00" />
					                    
                    <select style="" name="unite_remise" id="unite_remise">
<?php
if ($unite_remise == "€") 
{
	echo '<option value="€" selected="selected">€</option>
						<option style="background-color: rgb(227, 227, 227);" value="%">%</option>';
}
elseif ($unite_remise == "%")
{
	echo '<option value="€">€</option>
						<option style="background-color: rgb(227, 227, 227);" value="%" selected="selected">%</option>';
}
else 
{
	echo '<option value="€">€</option>
						<option style="background-color: rgb(227, 227, 227);" value="%">%</option>';
}
	
?>                    
                    
                    
						
					</select> 
					<input name="ht_ou_ttc" id="ht_ou_ttc" value="ht" type="hidden" />
				</div>				
		
				
				<div class="ligne_qte fleft acenter">
					Qté<br />
					<input class="textfield fleft aright" value="<?php if ($action== 'modif_ligne') {echo $qte;} else {echo '1';} ?>" id="qte" name="qte" type="text" />
                    <a href="#" class="qte_plus"><img src="../images/plus.png" alt="+" style="margin: 2px;"></a>
					<a href="#" class="qte_moins"><img src="../images/moins.png" alt="-" style="margin: 2px;"></a>
				</div>


			
				<div class="ligne_tva fleft acenter">
					TVA<br>
					<select name="tva" id="tva" />

<?php
// On récupère les données nécessaires à la suite du traitement des taux de TVA
$champs_tva = ' ';
				
for ($i=0; $i < count($_SESSION['taux_tva']); $i++)
	{
								
	$table_TVA[$i] = $_SESSION['taux_tva'][$i];
								
if($_SESSION['taux_tva'][$i] == $tva) //$tva étant le taux tva en cours pour le produit
	{
		$selected = "selected='selected'";
		
	}	
elseif ($champs_tva == $_SESSION['taux_tva'][$i]) 
	{
	$selected = "selected='selected'";
	}

else{
	$selected = '&nbsp;';
	}




								// $tva[$i]=$data['tva'];
$champs_tva = $champs_tva."<option value='".$_SESSION['taux_tva'][$i]."'".$selected.">".$_SESSION['taux_tva'][$i]." %</option>";
							}
$taille_table_TVA = count($table_TVA); // Quelle taille fait donc notre table ?



echo $champs_tva;	
?> 
                    
</select>
				</div>
				


				<div class="ligne_montant fleft acenter">
					Montant TTC<br>
					<input class="textfield aright" name="montant" id="montant" value="<?php echo $montant; ?>" type="text">&nbsp;€
				</div>
				
								
				
				
				<div class="ligne_detail margin-top clear">
				Détail : <br>
					<textarea name="detail" id="detail" rows="5" cols="50"><?php echo $detail; ?></textarea>
				</div>




			
			
<?php

// Ici on va définir si il faut afficher "insérer ligne" ou "modifier ligne"     
if ($action == 'modif_ligne') 
	{
?>
<p class="acenter">
					<a class="button" onclick='javascript:document.getElementById("devis_form").submit()' id="modifier_ligne_doc"><span><img alt="Modifier ligne" src="../images/pencil.png"> Modifier cette ligne</span></a>
				</p>
<?php                
	}
else
	{
?>		
		<p class="acenter">
					<a class="button" onclick='javascript:document.getElementById("devis_form").submit()' id="ajouter_ligne_doc"><span><img alt="Ajouter ligne" src="../images/disk.png"> Insérer cette ligne</span></a>
				</p>
<?php                
	}
?>   
        
        		
				
			</div>
			
<?php
if (isset($fact_data)){
?>
			
            
			<span id="tableauLignes">
		<table id="tab_document" class="margin-top" cellspacing="0">
			<tbody><tr>
				<th width="20">#</th>
				<th>Designation</th>
				<th width="70">Prix u. HT</th>
                <th width="50">Qté</th>
				<th width="100">Remise HT</th>
                <th width="100">Ristourne HT</th>	
				<th width="70">Montant HT</th>
			</tr>
            
<?php
// Nous allons charger les paramètres du tableau contenant les données de factures ( $fact_data ). Notre tableau à la forme $fact_data[$ligne]["valeur"]

$tab_fact_max = count($fact_data);
for ($i=0; $i<$tab_fact_max; $i++){
	
// Premièrement je calcule sur l'élément en cours son Prix HT* quantité moins la remise

	// On en profite pour calculer le total prix unitaire * quantité
	$elem_HT = $fact_data[$i]['prix']*$fact_data[$i]['qte'];

	// Pour cela, je veux savoir si il s'agit d'une remise en € ou en % 
	// Si jamais l'unite de remise est l'euro, on fait une simple 		addition sinon on converti d'abord en euros avant d'additionner en dessous...

// Je crée une valeur _tmp afin de la ré-utiliser

if ($fact_data[$i]['unite_remise']=="€")
		{
			$remise_HT_tmp = $fact_data[$i]['remise'];	
		}
	else {
			$remise_HT_tmp = $elem_HT*($fact_data[$i]['remise']/100);
		}
	
// On en profite pour calculer le total prix unitaire * quantité
	$elem_HT = $fact_data[$i]['prix']*$fact_data[$i]['qte'];		
		
		
	// Ensuite je peux effectuer le calcul... Pour ce faire j'enlève encore les X pourcents de Ristourne client ( celle qui se trouve dans les paramètres du client... La Ristourne globale donc !	
	
$prix_HT = $elem_HT-$remise_HT_tmp;  // j'enlève déjà la 1ere remise sur le produit que j'ai calculé ci-dessus...

	// Je calcule maintenant le montant la ristourne globle en €

	$ristourne_globale_calc = $elem_HT*($_SESSION['infos_generales']['ristourne_globale']/100);

	// Et je soustrait ma ristourne globale du prix...
	
	$prix_HT = $prix_HT - $ristourne_globale_calc;


// Je calcule maintenant la TVA sur ce prix HT - remise - ristourne

$tva_de_prix = $prix_HT*($fact_data[$i]['tva']/100);

// Maintenant je dois classifier les TVAs...
// Donc : Est-ce que j'ai une base à 6, 12 ou 21 ? Je vais comparer dans mon tableau des valeurs...

// Je me crée une boucle qui va regarder les divers taux proposés. Ensuite comparer les taux avec celui en cours $fact_data[$i]['tva']. Si c'est le même, on ajoute le montant à la variable adéquate.

for($j=0; $j<$taille_table_TVA; $j++)
{

$tmp = $fact_data[$i]['tva']; // par simplicité de lecture pour la suite...

if ($table_TVA[$j] == $tmp)
	{
		$total_base_TVA[$tmp] = $total_base_TVA[$tmp] + $prix_HT;
		$total_TVA[$tmp] = $total_TVA[$tmp] + $tva_de_prix;
	}
}

// TOUTES LES INFOS POUR LE TABLEAU TVA SONT DONC LA...

// Maintenant on s'attaque au tableau récapitulatif...

// Je calcule donc le montant hors TVA 	
	
	$montant_HT = $montant_HT + $prix_HT;

	
	
	echo '<tr id="'.$i.'"><td class="vtop">'.$i.'</td>
	 <td class="aleft">
		<div>'.$fact_data[$i]['designation'].'</div>'.$fact_data[$i]['detail'].'
<p style="visibility: hidden;" class="ligne_modifs"><a href="?action=modif_ligne&id='.$i.'" class="modif_ligne simple_button margin-right small">

<img src="../images/pencil.png" alt="Modifier"> Modifier la ligne</a> <a href="?action=supp_ligne&id='.$i.'" class="simple_button suppr_ligne small"><img src="../images/delete_001.png" alt="Supprimer"> Supprimer la ligne</a></p>
							</td>
<td class="vtop cell_prix_ht aright">'.$fact_data[$i]['prix'].' &euro;</td>

<td class="vtop cell_qte aright">'.$fact_data[$i]['qte'].'</td>							
														
<td class="vtop cell_remise aright">'.$remise_HT_tmp.' €';
// si l'unité de la remise est le % alors on affiche :
	if ($fact_data[$i]['unite_remise'] == "%")
		{
			echo '<p style="font-size:9px">'.$fact_data[$i]['remise'].' '.$fact_data[$i]['unite_remise'].'</p></td>';
		}
		
// Si il y a une ristourne globale on l'affiche
echo '<td class="vtop cell_remise aright">';

if (isset($infos_generales['ristourne_globale']) && $infos_generales['ristourne_globale'] != '0' && $infos_generales['ristourne_globale'] != '' )
	{
		echo $ristourne_globale_calc.' €<p style="font-size:9px">'.$infos_generales['ristourne_globale'].'% </p>';
	}	

echo '</td>
							
							
							<td class="vtop cell_total aright">'.$prix_HT.' &euro;
							<p style="font-size:12px">TVA : '.$fact_data[$i]['tva'].' %</p>					
							</td>
						</tr>';
}

// Et je continue ici le calcul sur le tableau récapitulatif
	

// Maintenant place à la remise globale sur le montant HT - remise HT en pourcents

	


// Calcul en direct du montant HT
$total_HT = $montant_HT; // Il s'agit d'une réminiscence d'ancien codes... Je garde ces 2 variables dans le doute... A nettoyer plus tard ! 



?>
						
						</tbody></table></span>
<?php
//fermeture du "if isset fact_data"
}
?>
		
					
		<input name="liste_tva" id="liste_tva" value="" type="hidden">
		<input name="montant_tva" id="montant_tva" value="" type="hidden">
		<input name="total_tva" id="total_tva" value="" type="hidden">
		<input name="total_port" id="total_port" value="0.00" type="hidden">
		<input name="montantHT" id="montantHT" value="" type="hidden">
		<input name="montantTTC" id="montantTTC" value="" type="hidden">
		<input name="montant_remise" id="montant_remise" value="1" type="hidden">			
			
			
		<hr>
		<div class="margin-top gras">
			Notes :<br>
			<textarea name="notes" cols="60" rows="6" class="large"><?php if (isset($infos_generales)) echo $infos_generales['notes']; ?></textarea>
		</div>
        
<br />  

<?php
// On va vérifier que la case co-contractants n'était pas cochée sinon on affiche à la place du tableau TVA la mention légale
if ($_SESSION['infos_generales']['cocontractants'] == "oui")
	{ 
		echo '<br /><br /><h3 class="cocontractants">Autoliquidation</h3>';
		$TVA_a_payer = '0'; // La TVA a payer devient 0€
	}
else // Donc si on est pas en cocontractants alors on calcule le total net + TVA et... C'est bon
	{
		
// TOTAL TTC !!!!!!!!!!!!!!!!!!!!!!
	// On calcule toute la TVA accumulée plus haut dans le tableau

for ($i=0;$i<$taille_table_TVA;$i++)
	{
$tmp = $table_TVA[$i];		
		
$TVA_a_payer = $TVA_a_payer + $total_TVA[$tmp]; 
	}

// On arrondi notre TVA
$TVA_a_payer = round($TVA_a_payer, 2);




		
		
		
		
		
		
		?>      
           
<div id="blocTVA"> <!-- Je crée ici un tableau de TVA -->
	<table class="tableau_tva margin-bottom margin-top" cellspacing="0">
    	<tr>
        	<td>
            Montant HT
            </td>
            <td>
            Taux TVA
            </td>
            <td>
            TVA calculée
            </td>
        <tr>

<?php


for($i=0; $i<$taille_table_TVA; $i++){
echo '<tr>';

if ($table_TVA[$i] != 0)
	{
$tmp = $table_TVA[$i];
$total_TVA[$tmp] = round($total_TVA[$tmp], 2);
	echo '<td>'.$total_base_TVA[$tmp].' €</td>';	
	echo '<td>'.$tmp.' %</td>';	
	// On va maintenant ajouter le total TVA inhérent au taux en cours
	echo '<td>'.$total_TVA[$tmp].' €</td>';
	

	}
echo '</tr>';
}

?>        
        
    </table>
</div>
<?php
} // Fin du if cocontractants

// Si il est cocontractant nous avons défini que tva a payer = 0... Si il n'est pas cocontractant nous avons aussi effectué le calcul afin de connaitre la tva à payer... On peut donc en tirer le total net

// Maintenant on peut ajouter au total HT la TVA	
	
$total_TTC= $total_HT+$TVA_a_payer;

?>
			
			
		<div id="blocTotaux">				
        <table class="tableau_totaux margin-bottom margin-top" cellspacing="0">
					<tbody>
					
								
					<tr><td>Total HT : <br></td><td><span id="totalHT">
<?php


echo $total_HT;?>&nbsp;€</span><br></td></tr>

<tr>
                    	<td>TVA : </td>
                    	<td id="totalTVA"> <?php echo $TVA_a_payer; ?>&nbsp;€</span>


</td></tr>


							
					<tr><td>Total TTC :</td><td id="totalTTC"><?php 
				
					echo $total_TTC; ?>&nbsp;€</td></tr>
                    
          
          
               
                    
                    
                    
<tr>
<td>Frais de port :</td>
<td><span id="totalFdp"><?php echo $infos_generales['frais_de_port'];?> €</span>
						</td>
					</tr>                    
                    
                    

<?php // calcul Net à payer
$total_net = $total_TTC + $infos_generales['frais_de_port'];

// Ensuite je regarde si il y avait un acompte, si oui je modifie la tableau pour qu'il calcule un sous total puis ensuite un Reste à payer

if (isset($infos_generales['acompte']) && $infos_generales['acompte'] != '0' && $infos_generales['acompte'] != '') {
	echo '
	<tr><th style="background-color: rgb(135, 206, 250); color: rgb(0, 0, 0);">Net TTC :</th><th id="netTTC" style="background-color: rgb(135, 206, 250); color: rgb(0, 0, 0);">'.$total_net.' €</th></tr>
	
	<tr>
		<td>Acompte</td>
		<td>- '.$infos_generales['acompte'].' €</td>
	</tr>';
	
// Calcul du reste à payer...	

$total_net = $total_net-$infos_generales['acompte'];
$valeur_a_afficher = "Restant à payer :";
}
else
	{
		$valeur_a_afficher = "Net à payer TTC :";
	}
?>					
	
						
                    
					<tr><th style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);"><?php echo $valeur_a_afficher; ?></th><th id="netTTC" style="background-color: rgb(0, 90, 155); color: rgb(255, 255, 255);"><?php echo $total_net; ?>&nbsp;€</th></tr>
				</tbody></table>
			</div>
			
		<hr>
			
		<p id="validation_ajout_devis" class="gris01 acenter">
			<!--
			<input type="submit" name="etat" value="Enregistrer en brouillon" class="margin-right" />
			<input type="submit" name="etat" value="Aperçu et enregistrer" />
			-->
			<input name="etat" value="Enregistrer & Imprimer" id="submit_form" type="hidden">
			
            
							<input  type="submit" name="imprime_doc" id="imprime_doc" value="Valider" />
                            
				
		</p>
	</form>	
			</div>	
		
	
	
	
	
</div>
</div>








</div>
<?php
include('./footer.php');
?>
</body>
</html>