<?php
// Session créée ? Sinon, en créer une nouvelle
if($PHPSESSID) session_start($PHPSESSID);
else session_start();

// Je vide mes variables de sessions m'ayant servi à créer mon document facture, devis ou bon de commande
	// Et maintenant je vide mes variables de session
				unset($_SESSION['fact_data']);
				unset($_SESSION['infos_generales']);
				unset($_SESSION['devis_data']);
				unset($_SESSION['bdc_data']);
				unset($_SESSION['facture_data']);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>Gestion des bons de commandes</title>
<meta name="keywords" content="" lang="fr">
<meta name="description" content="">

<meta http-equiv="Content-Language" content="fr">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<!--[if IE]><script language="javascript" type="text/javascript" src="http://www.wuro.fr/static/js/excanvas.js"></script><![endif]-->	

</head>
<body>



<?php
include ("./menu.php");

// Pour notre recherche, je recharge ici les données éventuelles du $_GET...

$rechDate = $_GET['date'];
$rechMontant = $_GET['montant'];
$rechRef = $_GET['ref'];
$rechEtat = $_GET['etat'];

// Maintenant, si un n'est pas vide, alors on rajoute un critère de recherche
$rechCritere = 'AND ';
if (!empty($rechDate))
{
	$newDate = explode('/', $rechDate);
	$rechDate = $newDate['2'].'-'.$newDate['1'].'-'.$newDate['0'];
	echo $rechDate;
	$rechCritere = $rechCritere.'dateDoc LIKE "%'.$rechDate.'%" ';
}
elseif (!empty($rechMontant))
{
	$rechCritere = $rechCritere.'montant LIKE "%'.$rechMontant.'%" ';
}
elseif (!empty($rechRef))
{
	$rechCritere = $rechCritere.'bdc_num LIKE "%'.$rechRef.'%" ';
}
elseif (!empty($rechEtat))
{
	// On va maintenant vérifier qu'il ne s'agit pas de Dépassé... Auquel car le critère est différent. On doit faire une recherche sur les dates...
	if ($rechEtat == "Dépassé")
	{
		$rechCritere = $rechCritere.'dev_dateValidite < CURDATE()';
	}
	else
	{
		$rechCritere = $rechCritere.'etat LIKE "'.$rechEtat.'" ';
	}
}
else 
{
	$rechCritere = '';
}


// Ici je vais accéder à ma liste de devis et stocker ses données dans une variable de session... Ca allégera la charge du serveur MySQL pour afficher les devis et même les modifier le cas échéant.	
mysql_query('set names utf8');		
// on crée la requete SQL
$sql_bdc = "SELECT * FROM ".$tab_bdc." WHERE dev_tva_affil LIKE '".$_SESSION['ent_tva']. "' ".$rechCritere." ORDER BY REPLACE(bdc_num, '/','')";  

// on envoie la requête 
$req_bdc = mysql_query($sql_bdc) or die('Erreur SQL !<br />'.$sql_bdc.'<br />'.mysql_error()); 

$cnt = 0; // J'initialise un petit compteur
$montantTotal = 0; // J'initialise le montant total
$cntVal = 0;

// Et maintennt je stocke dans une variable de session
while($data_bdc = mysql_fetch_array($req_bdc))  
    {	
	$bdc_data[$cnt] = array( 					id => $data_bdc['id'],
												dev_tva_affil => $data_bdc['dev_tva_affil'],
												devNum => $data_bdc['dev_num'],
												bdcNum => $data_bdc['bdc_num'],
												factNum => $data_bdc['fact_num'],
												annexes_id => $data_bdc['annexes_id'],
												dateDoc => $data_bdc['dateDoc'],
												frais_de_port => $data_bdc['dev_frais_de_port'],
												nomClient => $data_bdc['dev_nomClient'],
												adresse => $data_bdc['dev_adresseClient'],
												code_postal => $data_bdc['dev_codePostal'],
												ville => $data_bdc['dev_ville'],
												pays => $data_bdc['dev_pays'],
												tva_intra => $data_bdc['tvaClient'], 
												code_client => $data_bdc['dev_codeClient'],
												mail_client => $data_bdc['dev_mailClient'],
												mode_reglement => $data_bdc['dev_modeReglement'],
												etat_payement => $data_bdc['dev_etatPayement'],
												fact_paye => $data_bdc['dev_factPayee'],
												fact_date => $data_bdc['dev_factDate'],
												ristourne_globale => $data_bdc['dev_ristourneGlobale'],
												notes => $data_bdc['dev_notes'],
												dateVal => $data_bdc['dev_dateValidite'],
												cocontractants => $data_bdc['dev_cocontract'],
												delai_reglement => $data_bdc['dev_delaiReglement'],
												acompte => $data_bdc['dev_aCompte'],
												dev_serialize => $data_bdc['dev_serialize'],
												tva => $data_bdc['tva'],
												montant => $data_bdc['montant'],
												etat => $data_bdc['etat'],
												date_etat => $data_bdc['date_etat'],
												chantier => $data_bdc['chantier'],
												actio => ''
												);
			$cnt++; // Et j'incrémente le tout 
			$montantTotal = $montantTotal + $data_bdc['montant'];
			
			if ($data_bdc['etat'] == "Validé")
		{
			$cntVal++;
			$montantValide = $montantValide + $data_bdc['montant'];
		}
		
		 
	}
$_SESSION['devis_data'] = $bdc_data;	


?>




<div id="contenant">
		<span class="hide" id="type_doc">bdc</span>
        <span class="hide" id="type_document">bdc</span>



<div class="box">
	<h2>Gestion des bons de commandes</h2>
	
	<!--###############################################################
	############################# MENU ################################
	###############################################################-->
    <ul id="menu">        <li>
			<a class="active" href="#" rel="bdc_list"><img src="../images/bdc64.png" alt="Liste des bons de commande"> <span>Liste des bons de commandes</span></a>
        </li>
			
		</ul>
    
    

	<div id="devis_list" class="content">
						<form action="" method="get" id="form_recherche_devis" class="search">
												 					<div class="fleft">
						<label for="src_date_devis">Date : </label><input name="date" id="src_date_devis" class="textfield datepicker hasDatepicker" value="" type="text">
                        </div>
                        <div class="fleft">
						<label for="src_montant">&nbsp;&nbsp;&nbsp;Montant : </label><input class="textfield number" name="montant" size="20" id="src_montant" value="" type="text"> €
                        </div>
												
	<div class="fleft">
                      
		<label for="src_reference_devis">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;N° bon de C. : </label>
    	<input autocomplete="off" name="ref" id="src_reference_devis" class="textfield code" value="" type="text" />
		<div class="suggestionsBox" id="suggestions_reference" style="left: 65px;">
			
				<div class="suggestionList" id="autoSuggestionsList_reference">
									&nbsp;
				</div>
			<div class="hide">
        	bdc/autoCompleteRef
        	</div>
        </div>    
	</div> 							
                           
                           
                            <div class="fleft">
								
							<label for="src_etat">&nbsp;&nbsp;&nbsp;Etat : </label>
							<select name="etat" id="src_etat">
								<option value="">Tous états</option>
								
								<option value="En attente">En attente</option>
								<option style="background-color: rgb(227, 227, 227);" value="Validé">Validé</option>
								<option value="Refusé">Refusé</option>
								<option style="background-color: rgb(227, 227, 227);" value="Dépassé">Dépassé</option>
							</select>
                            </div>

						 <a href="#" class="button submit"><span><img src="../images/magnifier.png" alt="Recherche">Rechercher</span></a>
		
				
					<span><a href="#" class="button bouton_deroulant"><span><img src="../images/advanced_search.png" alt="Recherche avancée"> Infos récapitulatives</span></a>
					</span>
                    
					
                    
                    <div class="hide" id="form_recherche_avancee">
						<div class="fleft">
						<?php // Je vais maintenant regarder ce que nous allons afficher...
						if ($cnt == '0')
						{
							echo 'Vous n\'avez aucun bon de commande créé.';
						}
						elseif ($cnt == '1')
						{
							echo 'Vous avez un 1 bon de commande créé dont le montant s\'élève à '.$montantTotal.' €.';
						}
						else
						{
							echo 'Vous avez un total de '.$cnt. ' bons de commandes créés pour un montant total de '.$montantTotal.' €. ';
							
							
							if ($cntVal == '0') // Je controle si il faut mettre au pluriel ou pas
							{ 
								echo 'Sur ces bons de commandes, aucun n\'est validé.';
							}
							elseif ($cntVal == '1') 
							{ 
								echo 'Un bon de commande est validé pour un montant de '.$montantValide.' €.';
							}
							else
							{
								echo 'Sur ces bons de commandes, '.$cntVal. ' sont validés pour un montant de '.$montantValide.' €.';
							}
						}
						?>
						
                        </div>
                        &nbsp;
                    </div>    
                            
                    </form>   
				</div>
				
				
								<table cellspacing="0">
					<tbody><tr>
                    	<th width="50">&nbsp;</th>
						<th class="aleft" width="80">▼ Numéro</th>
						<th width="80">▼ Date</th>
						<th class="aleft" width="140">▼ Code Client</th>
						<th width="120">▼ Nom Client</th>
						<th width="90">▼ Montant</th>
						<th width="100">▼ Etat</th>
						<th>Actions</th>
						
					</tr>
							
			
<?php
if (empty($bdc_data) && !empty($rechCritere))
{ 
	echo '<tr><td colspan="9" class="acenter">
            Aucun résultat pour votre recherche, essayez d\'autres critères.
            </td></tr>';
}
elseif (empty($bdc_data))
	{ echo '<tr><td colspan="9" class="acenter">
            Aucun Bon de commande créé
            </td></tr>';
	}
else {
	$tab_bdc_data_count = count($bdc_data);


for ($i=0; $i<$tab_bdc_data_count; $i++)
	{
		
		// Nous devons en plus vérifier qu'il ne s'agisse pas d'un sous/bon de commande... Si tel est le cas nous devons afficher la petite fleche rouge et non un numéro. Pour déterminer ça, j'explode et je vérifie que la position 3 est égale à la précédente
		$numExplose = explode('/', $bdc_data[$i]['bdcNum']);
		// $numAVerifier = $numExplose[1].$numExplose[2];
		// j'étais parti sur un if $numAVerifier == $oldNumExplose MAIS je remplace ça par !empty
		// Ca fonctionne et ça permet surtout de ne pas fausser l'affichage des résultats lors d'une recherche...
		if (!empty($numExplose[3]))
		{
			echo '<tr>
			<td class="acenter" id="noeud"><input id="doc_id" type="hidden" value="'.$bdc_data[$i]['id'].'" />
			<img src="../images/inherit32.png" alt="Bon de commande lié" class="inline" /></td>';
			// De plus je dois créer une variable de session qui va stocker mes infos d'annexes, de façon a pouvoir créer facilement une nouvelle annexe sans avoir à ouvrir la base plus tard
			$_SESSION['annexes'][$numExplose[2]] = $numExplose[3]; // Autrement dit, si j'ai le bon de commande 009 avec 2 annexes, je place à la position 009 la valeur 2... il suffira de faire $_SESSION['annexes'][$numExplose[2]]++ et j'ai mon nouveau numéro d'annexe...
		}
		else
		{
		$j++;
		echo '
		<tr>
			<td colspan="8"></td>
		</tr>
		<tr class="tete_liste">
		<td class="acenter" id="noeud" onclick="window.location.href=\'visualiser.html?origine=bdc&id='.$bdc_data[$i]['id'].'\';"><input id="doc_id" type="hidden" value="'.$bdc_data[$i]['id'].'" />'.$j.'</td>';
		} // fin du if/else est égal au oldNumExplose
// Afin de s'en reservir lors de la prochaine boucle
		echo'<td align="left" onclick="window.location.href=\'visualiser.html?origine=bdc&id='.$bdc_data[$i]['id'].'\';">'.$bdc_data[$i]['bdcNum'].'</td>
			<td class="acenter" onclick="window.location.href=\'visualiser.html?origine=bdc&id='.$bdc_data[$i]['id'].'\';">'.$bdc_data[$i]['dateDoc'].'</td>
			<td class="acenter" onclick="window.location.href=\'visualiser.html?origine=bdc&id='.$bdc_data[$i]['id'].'\';">'.$bdc_data[$i]['code_client'].'<br /><p style="font-size:9px">'.$bdc_data[$i]['chantier'].'</p></td>
			<td class="acenter" onclick="window.location.href=\'visualiser.html?origine=bdc&id='.$bdc_data[$i]['id'].'\';">'.$bdc_data[$i]['nomClient'].'</td>
			<td class="acenter" onclick="window.location.href=\'visualiser.html?origine=bdc&id='.$bdc_data[$i]['id'].'\';">'.$bdc_data[$i]['montant'].'€</td>
			<td class="vtop aleft">';
			
	// Gestion des états.			

		
		switch($bdc_data[$i]['etat']){
			case 'En attente':
				echo '&nbsp;<img src=../images/diode_orange.png alt="En attente" class="inline" />&nbsp;<a href="#" class="changer_etat underline">'.$bdc_data[$i]['etat'].'</a>';
				break;
			case 'Validé':
				echo '&nbsp;<img src=../images/diode_verte.png alt="Validé" class="inline" />&nbsp;<a href="#" class="changer_etat underline">'.$bdc_data[$i]['etat'].'</a>
				<br />
				<div style="font-size:9px;">&nbsp;&nbsp;'.$bdc_data[$i]['date_etat'].'</div>
				';
				break;
			case 'Refusé':
				echo '&nbsp;<img src=../images/diode_rouge.png alt="Refusé" class="inline" />&nbsp;<a href="#" class="changer_etat underline">'.$bdc_data[$i]['etat'].'</a>';
				break;
		}		
			
			
			
			
			
	echo '</td>
			
			<td align="right">'; // Je viens de créer ma derniere colonne avec les divers raccourcis...
			
// Je regarde si je dois ajouter une option de création de nouveau bon de commande ou pas
		if (empty($numExplose[3]))	
		{
			echo '<a href="ajouter_un_bon_de_commande.html?origine=bdc&numDoc='.$i.'&inherit='.$bdc_data[$i]['bdcNum'].'" title="Créer une annexe au bon de commande"><img src="../images/new_doc32.png" alt="Créer une annexe au bon de commande" class="inline"></a>';	
		}
// A l'inverse, si c'est un bon de commande primaire, on ne doit plus savoir le modifier vu qu'il est hérité des devis			
		if (!empty($numExplose[3]) && $bdc_data[$i]['etat'] != "Validé")	
		{		
			echo '<a href="ajouter_un_bon_de_commande.html?origine=bdc&numDoc='.$i.'" title="Modifier" style="margin-left: 8px;"><img src="../images/pencil.png" alt="Modifier" class="inline"></a>';
		}
		
			echo '<a href="ajouter_une_facture.html?origine=facture&numDoc='.$i.'" title="Transformer en facture" style="margin-left: 8px;"><img src="../images/go2fac.png" alt="bdc" class="inline"></a>';
										
										if ($bdc_data[$i]['etat'] != "Validé" )
	{									
										echo '<a href="suppression.html?origine=bdc&numDoc='.$bdc_data[$i]['id'].'"';?> onclick="return(confirm('Etes-vous sûr de vouloir supprimer cette entrée?'));"<?php echo 'title="Supprimer" style="margin-left: 5px;"><img src="../images/delete.png" alt="Supprimer" class="inline"></a>';
	}else
	{
		echo '<img src="../images/delete_blk.png" class="inline" style="margin-left: 5px;" />';
	}
										
                                       
						echo '</td>
									
									</tr>';
		
$oldNumExplose = $numAVerifier;		
	}
}
?>			
			</tbody></table>			
	</div>
	
	
		
	<div id="devis_add" class="hide content">
			</div>	


</div>
</div>



<?php
include('./footer.php');
?>
</html>
