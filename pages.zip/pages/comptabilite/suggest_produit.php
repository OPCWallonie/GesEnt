<?php


##############################################################################################################

// Paramètres de connexion à la base de données
$db_host 						= 'localhost'; 						// Nom du serveur
$db_login					 	= 'root';							// Nom d'utilisateur
$db_pass 						= 'root';							// Mot de passe
$db_base 						= 'gesent'; 							// Nom de la base de données



 $q=$_GET['q'];
 $my_data=mysql_real_escape_string($q);
 $mysqli=mysqli_connect($db_host,$db_login,$db_pass,$db_base) or die("Base de données introuvable");
 $sql="SELECT nomProduit FROM gf_produits WHERE nomProduit LIKE '%$my_data%' ORDER BY nomProduit";
 $result = mysqli_query($mysqli,$sql) or die(mysqli_error());

 if($result)
 {
  while($row=mysqli_fetch_array($result))
  {
   echo $row['nomProduit']."\n";
  }
 }
?>